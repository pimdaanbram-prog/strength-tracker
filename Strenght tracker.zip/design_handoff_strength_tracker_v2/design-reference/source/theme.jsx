/* ========== GLASSMORPHIC THEME + ACCENT SYSTEM ========== */

// Accent presets — user can swap live from Settings
const ACCENTS = {
  tangerine: { name: 'Tangerine', hue: 18,  c1: '#FF7A1F', c2: '#FFB020' },
  electric:  { name: 'Electric',  hue: 210, c1: '#3D7CFF', c2: '#00D9FF' },
  neon:      { name: 'Neon',      hue: 135, c1: '#3EE8A8', c2: '#9CFF4A' },
  iris:      { name: 'Iris',      hue: 280, c1: '#B76DFF', c2: '#FF6FD8' },
  magma:     { name: 'Magma',     hue: 350, c1: '#FF3D6E', c2: '#FFB020' },
  arctic:    { name: 'Arctic',    hue: 195, c1: '#A0E9FF', c2: '#E0F4FF' },
};

// Default theme object — gets merged with live accent
const makeTheme = (accentKey = 'tangerine') => {
  const a = ACCENTS[accentKey] || ACCENTS.tangerine;
  return {
    accentKey,
    accentName: a.name,
    accent: a.c1,
    accentHi: a.c2,
    accentGrad: `linear-gradient(135deg, ${a.c1} 0%, ${a.c2} 100%)`,
    accentGlow: `${a.c1}55`,
    accentSoft: `${a.c1}22`,
    accentHue: a.hue,

    // base (deep space-ish)
    bg: '#060608',
    bgElev: '#0C0C10',
    // glass
    glass: 'rgba(255,255,255,0.06)',
    glassHi: 'rgba(255,255,255,0.09)',
    glassBorder: 'rgba(255,255,255,0.12)',
    glassBorderHi: 'rgba(255,255,255,0.18)',
    // text
    text: '#F5F5F7',
    textDim: 'rgba(235,235,245,0.72)',
    textMute: 'rgba(235,235,245,0.45)',
    textFaint: 'rgba(235,235,245,0.25)',
    // semantics
    success: '#3EE8A8',
    warning: '#FFB020',
    error: '#FF4D4D',
    // type
    sans: '"Inter", -apple-system, sans-serif',
    display: '"Space Grotesk", "Inter", sans-serif',
    mono: '"JetBrains Mono", ui-monospace, monospace',
  };
};

// React context so components can reactively re-read accent
const ThemeCtx = React.createContext(makeTheme('tangerine'));
const useTheme = () => React.useContext(ThemeCtx);

const ThemeProvider = ({ children }) => {
  const [accentKey, setAccentKey] = React.useState(() => {
    try { return localStorage.getItem('st_accent') || 'tangerine'; } catch { return 'tangerine'; }
  });
  const theme = React.useMemo(() => ({
    ...makeTheme(accentKey),
    setAccent: (k) => {
      setAccentKey(k);
      try { localStorage.setItem('st_accent', k); } catch {}
    },
    accentList: ACCENTS,
  }), [accentKey]);

  // Inject ambient hue-based gradient into :root for background layers
  React.useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--accent', theme.accent);
    root.style.setProperty('--accent-hi', theme.accentHi);
    root.style.setProperty('--accent-glow', theme.accentGlow);
    root.style.setProperty('--accent-hue', theme.accentHue);
  }, [theme]);

  return <ThemeCtx.Provider value={theme}>{children}</ThemeCtx.Provider>;
};

/* ========== GLASS PRIMITIVES ========== */

const GlassCard = ({ children, style = {}, hi = false, blur = 24, onClick, ...rest }) => {
  const T = useTheme();
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        background: hi ? T.glassHi : T.glass,
        backdropFilter: `blur(${blur}px) saturate(180%)`,
        WebkitBackdropFilter: `blur(${blur}px) saturate(180%)`,
        border: `1px solid ${hover ? T.glassBorderHi : T.glassBorder}`,
        borderRadius: 22,
        boxShadow: '0 8px 32px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.08)',
        transition: 'transform 0.25s cubic-bezier(.2,.8,.2,1), border-color 0.2s',
        transform: onClick && hover ? 'translateY(-1px)' : 'translateY(0)',
        cursor: onClick ? 'pointer' : 'default',
        overflow: 'hidden',
        ...style,
      }}
      {...rest}
    >
      {/* specular top highlight */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 1,
        background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent)',
        pointerEvents: 'none',
      }} />
      {children}
    </div>
  );
};

const GlassPill = ({ children, tone = 'default', style = {} }) => {
  const T = useTheme();
  const tones = {
    default: { bg: T.glass, color: T.textDim, border: T.glassBorder },
    accent:  { bg: T.accentSoft, color: T.accent, border: `${T.accent}44` },
    success: { bg: 'rgba(62,232,168,0.12)', color: T.success, border: 'rgba(62,232,168,0.25)' },
    warning: { bg: 'rgba(255,176,32,0.12)', color: T.warning, border: 'rgba(255,176,32,0.25)' },
  };
  const t = tones[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      fontSize: 9.5, fontFamily: T.mono, fontWeight: 600,
      letterSpacing: '0.08em', textTransform: 'uppercase',
      padding: '4px 8px', borderRadius: 999,
      background: t.bg,
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      color: t.color, border: `1px solid ${t.border}`,
      ...style,
    }}>{children}</span>
  );
};

const SectionLabel = ({ children, right = null }) => {
  const T = useTheme();
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, padding: '0 20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ width: 3, height: 12, background: T.accentGrad, borderRadius: 2, boxShadow: `0 0 12px ${T.accentGlow}` }} />
        <span style={{
          fontSize: 10, fontFamily: T.mono, fontWeight: 700,
          letterSpacing: '0.14em', textTransform: 'uppercase',
          color: T.textDim,
        }}>{children}</span>
      </div>
      {right}
    </div>
  );
};

/* ========== ICONOGRAPHY ========== */
const Icon = ({ name, size = 18, color = 'currentColor', stroke = 1.75 }) => {
  const p = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (name) {
    case 'home': return <svg {...p}><path d="M3 10l9-7 9 7v10a2 2 0 01-2 2h-4v-7h-6v7H5a2 2 0 01-2-2V10z"/></svg>;
    case 'dumbbell': return <svg {...p}><path d="M6 8v8M4 10v4M18 8v8M20 10v4M6 12h12"/></svg>;
    case 'bookmark': return <svg {...p}><path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/></svg>;
    case 'chart': return <svg {...p}><path d="M3 3v18h18M7 14l4-4 4 4 5-5"/></svg>;
    case 'user': return <svg {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/></svg>;
    case 'play': return <svg {...{...p, fill: color, stroke: 'none'}}><path d="M6 4l14 8-14 8V4z"/></svg>;
    case 'pause': return <svg {...{...p, fill: color, stroke: 'none'}}><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>;
    case 'plus': return <svg {...p}><path d="M12 5v14M5 12h14"/></svg>;
    case 'check': return <svg {...p}><path d="M5 12l5 5L20 7"/></svg>;
    case 'flame': return <svg {...p}><path d="M12 2s4 4 4 9a4 4 0 01-8 0c0-2 1-3 1-3s-3 2-3 6a6 6 0 0012 0c0-7-6-12-6-12z"/></svg>;
    case 'trophy': return <svg {...p}><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0V4zM7 4H4v3a3 3 0 003 3M17 4h3v3a3 3 0 01-3 3"/></svg>;
    case 'zap': return <svg {...{...p, fill: color, stroke: 'none'}}><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/></svg>;
    case 'clock': return <svg {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>;
    case 'arrow-right': return <svg {...p}><path d="M5 12h14M13 6l6 6-6 6"/></svg>;
    case 'arrow-up': return <svg {...p}><path d="M12 19V5M6 11l6-6 6 6"/></svg>;
    case 'arrow-down': return <svg {...p}><path d="M12 5v14M6 13l6 6 6-6"/></svg>;
    case 'chevron-right': return <svg {...p}><path d="M9 6l6 6-6 6"/></svg>;
    case 'chevron-left': return <svg {...p}><path d="M15 6l-6 6 6 6"/></svg>;
    case 'chevron-down': return <svg {...p}><path d="M6 9l6 6 6-6"/></svg>;
    case 'chevron-up': return <svg {...p}><path d="M18 15l-6-6-6 6"/></svg>;
    case 'x': return <svg {...p}><path d="M6 6l12 12M6 18L18 6"/></svg>;
    case 'search': return <svg {...p}><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>;
    case 'settings': return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>;
    case 'calendar': return <svg {...p}><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>;
    case 'trend-up': return <svg {...p}><path d="M23 6l-9.5 9.5-5-5L1 18M17 6h6v6"/></svg>;
    case 'target': return <svg {...p}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></svg>;
    case 'filter': return <svg {...p}><path d="M3 6h18M6 12h12M10 18h4"/></svg>;
    case 'dots': return <svg {...{...p, fill: color, stroke: 'none'}}><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>;
    case 'bell': return <svg {...p}><path d="M6 8a6 6 0 0112 0c0 7 3 9 3 9H3s3-2 3-9M13.73 21a2 2 0 01-3.46 0"/></svg>;
    case 'rotate': return <svg {...p}><path d="M1 4v6h6M23 20v-6h-6M20.49 9A9 9 0 005.64 5.64L1 10M3.51 15a9 9 0 0014.85 3.36L23 14"/></svg>;
    case 'palette': return <svg {...p}><circle cx="13.5" cy="6.5" r="0.5" fill={color}/><circle cx="17.5" cy="10.5" r="0.5" fill={color}/><circle cx="8.5" cy="7.5" r="0.5" fill={color}/><circle cx="6.5" cy="12.5" r="0.5" fill={color}/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c3.31 0 6-2.69 6-6 0-5.52-4.48-10-10-10z"/></svg>;
    case 'sparkles': return <svg {...p}><path d="M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2 2-5z"/></svg>;
    case 'weight': return <svg {...p}><path d="M6 7h12l-1 12H7L6 7z"/><path d="M9 7V5a3 3 0 016 0v2"/></svg>;
    default: return null;
  }
};

Object.assign(window, { ThemeCtx, ThemeProvider, useTheme, GlassCard, GlassPill, SectionLabel, Icon, ACCENTS });
