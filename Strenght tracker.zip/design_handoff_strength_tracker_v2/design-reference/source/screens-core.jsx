/* ============================================================
   CORE SCREENS — Dashboard, Workout, Progress (with 3D figure)
   ============================================================ */

const ScreenShell = ({ children, style = {}, bgIntensity = 1 }) => {
  const T = useTheme();
  return (
    <div style={{
      position: 'relative', width: '100%', height: '100%',
      background: T.bg, color: T.text, fontFamily: T.sans, fontSize: 14,
      overflow: 'hidden', display: 'flex', flexDirection: 'column',
      ...style,
    }}>
      <AmbientBackground intensity={bgIntensity} />
      <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', height: '100%' }}>
        {children}
      </div>
    </div>
  );
};

const ScrollArea = ({ children, style = {} }) => (
  <div style={{ flex: 1, overflow: 'auto', ...style }} className="hide-scrollbar">{children}</div>
);

/* ========== BOTTOM NAV (glass) ========== */
const BottomNav = ({ active = 'home', onSelect = () => {} }) => {
  const T = useTheme();
  const items = [
    { id: 'home', label: 'Home', icon: 'home' },
    { id: 'workout', label: 'Train', icon: 'dumbbell' },
    { id: 'progress', label: 'Progress', icon: 'chart' },
    { id: 'history', label: 'Historie', icon: 'calendar' },
    { id: 'settings', label: 'Instellingen', icon: 'settings' },
  ];
  return (
    <div style={{
      position: 'absolute', left: 12, right: 12, bottom: 18,
      padding: 6,
      background: 'rgba(12,12,18,0.55)',
      backdropFilter: 'blur(28px) saturate(180%)',
      WebkitBackdropFilter: 'blur(28px) saturate(180%)',
      border: `1px solid ${T.glassBorder}`,
      borderRadius: 24,
      boxShadow: '0 16px 48px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.1)',
      display: 'flex', gap: 2,
      zIndex: 20,
    }}>
      {items.map(it => {
        const isActive = it.id === active;
        return (
          <SpringButton key={it.id} onClick={() => onSelect(it.id)} style={{
            flex: 1, position: 'relative',
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', gap: 3,
            padding: '10px 0', background: 'transparent',
            color: isActive ? T.accent : T.textMute,
            borderRadius: 18,
          }}>
            {isActive && (
              <div style={{
                position: 'absolute', inset: 2,
                background: T.accentSoft,
                borderRadius: 16,
                border: `1px solid ${T.accent}44`,
                boxShadow: `inset 0 0 20px ${T.accentGlow}`,
              }} />
            )}
            <div style={{ position: 'relative', zIndex: 1 }}>
              <Icon name={it.icon} size={18} color={isActive ? T.accent : T.textMute} />
            </div>
            <span style={{ position: 'relative', zIndex: 1, fontSize: 9, fontWeight: 600, letterSpacing: '0.02em' }}>{it.label}</span>
          </SpringButton>
        );
      })}
    </div>
  );
};

/* ========== DASHBOARD ========== */
const DashboardScreen = ({ onNavigate = () => {} }) => {
  const T = useTheme();

  const weekDots = [1,1,1,0,1,1,0];
  const todayIdx = 4;

  return (
    <ScreenShell>
      <ScrollArea style={{ paddingBottom: 130 }}>
        <StatusSpacer />

        {/* Header */}
        <div style={{ padding: '12px 20px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 42, height: 42, borderRadius: 14,
              background: T.accentGrad,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: T.display, fontWeight: 800, fontSize: 16, color: 'white',
              boxShadow: `0 8px 24px ${T.accentGlow}, inset 0 1px 0 rgba(255,255,255,0.3)`,
            }}>P</div>
            <div>
              <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 700 }}>Donderdag · 23 APR</div>
              <div style={{ fontSize: 16, fontWeight: 600, marginTop: 2 }}>Hey Pim 👋</div>
            </div>
          </div>
          <GlassCard style={{ padding: 10, borderRadius: 14 }}>
            <Icon name="bell" size={17} color={T.textDim} />
          </GlassCard>
        </div>

        {/* Hero workout card with tilt */}
        <div style={{ padding: '0 20px', marginBottom: 22 }}>
          <StaggerItem delay={100}>
            <TiltCard max={6}>
              <GlassCard hi style={{ padding: 22, overflow: 'hidden', position: 'relative' }}>
                {/* orb */}
                <div style={{
                  position: 'absolute', top: -60, right: -40, width: 220, height: 220,
                  background: `radial-gradient(circle, ${T.accent}88, transparent 70%)`,
                  filter: 'blur(30px)',
                  animation: 'orbPulse 4s ease-in-out infinite',
                }} />

                <div style={{ position: 'relative', transform: 'translateZ(20px)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12 }}>
                    <GlassPill tone="accent">Aanbevolen</GlassPill>
                    <GlassPill>45 min · 8 oef.</GlassPill>
                  </div>
                  <div style={{ fontFamily: T.display, fontSize: 32, fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1 }}>Push Day</div>
                  <div style={{ fontSize: 13, color: T.textDim, marginTop: 6 }}>Borst · Schouders · Triceps</div>

                  {/* muscle dots */}
                  <div style={{ display: 'flex', gap: 5, marginTop: 16, marginBottom: 20, flexWrap: 'wrap' }}>
                    {['Borst','Schouder','Triceps','Core'].map((m, i) => (
                      <div key={i} style={{
                        fontSize: 9.5, fontFamily: T.mono, fontWeight: 600,
                        color: T.textDim, padding: '5px 10px',
                        background: 'rgba(255,255,255,0.04)',
                        border: `1px solid ${T.glassBorder}`,
                        borderRadius: 999,
                        letterSpacing: '0.06em',
                      }}>{m.toUpperCase()}</div>
                    ))}
                  </div>

                  <SpringButton onClick={() => onNavigate('workout')} style={{
                    width: '100%', padding: '16px 18px',
                    background: T.accentGrad, color: 'white', borderRadius: 16,
                    fontWeight: 700, fontSize: 14, letterSpacing: '0.02em',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                    boxShadow: `0 12px 32px ${T.accentGlow}, inset 0 1px 0 rgba(255,255,255,0.3)`,
                  }}>
                    <Icon name="play" size={13} color="white" /> START WORKOUT
                    <Icon name="arrow-right" size={14} color="white" stroke={2.5} />
                  </SpringButton>
                </div>
              </GlassCard>
            </TiltCard>
          </StaggerItem>
        </div>

        {/* Week strip */}
        <div style={{ padding: '0 20px', marginBottom: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textDim, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 700 }}>Deze week</div>
            <div style={{ fontSize: 11, color: T.textDim, fontFamily: T.mono, fontWeight: 600 }}>3 / 5 doel</div>
          </div>
          <StaggerItem delay={200}>
            <GlassCard style={{ padding: 14, display: 'flex', gap: 6 }}>
              {['M','D','W','D','V','Z','Z'].map((d, i) => {
                const active = weekDots[i] === 1;
                const isToday = i === todayIdx;
                return (
                  <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                    <div style={{ fontSize: 10, fontFamily: T.mono, color: isToday ? T.accent : T.textMute, fontWeight: 700 }}>{d}</div>
                    <div style={{
                      width: '100%', height: 52, borderRadius: 12,
                      background: active ? T.accentGrad : 'rgba(255,255,255,0.04)',
                      border: isToday ? `1.5px solid ${T.accent}` : `1px solid ${T.glassBorder}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      boxShadow: active ? `0 6px 18px ${T.accentGlow}` : 'none',
                      position: 'relative', overflow: 'hidden',
                    }}>
                      {active && <Icon name="check" size={15} color="white" stroke={2.5} />}
                      {isToday && !active && <div style={{ width: 7, height: 7, borderRadius: '50%', background: T.accent, boxShadow: `0 0 12px ${T.accent}` }} />}
                    </div>
                  </div>
                );
              })}
            </GlassCard>
          </StaggerItem>
        </div>

        {/* Stats — big glass tiles */}
        <div style={{ padding: '0 20px', marginBottom: 22 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
            {[
              { label: 'Streak', value: 12, unit: 'd', icon: 'flame', color: T.warning },
              { label: "PR's", value: 7, unit: '', icon: 'trophy', color: T.success },
              { label: 'Volume', value: 7.4, unit: 'k', icon: 'zap', color: T.accent, dec: 1 },
            ].map((s, i) => (
              <StaggerItem key={i} delay={260 + i * 80}>
                <GlassCard style={{ padding: 14, position: 'relative', overflow: 'hidden' }}>
                  <div style={{ position: 'absolute', top: 10, right: 10, opacity: 0.9 }}>
                    <Icon name={s.icon} size={14} color={s.color} />
                  </div>
                  <div style={{ fontFamily: T.display, fontSize: 30, fontWeight: 700, marginTop: 18, letterSpacing: '-0.03em', lineHeight: 1 }}>
                    <TickerNumber value={s.value} decimals={s.dec || 0} />
                    <span style={{ fontSize: 14, color: T.textMute, marginLeft: 2, fontWeight: 500 }}>{s.unit || ''}</span>
                  </div>
                  <div style={{ fontSize: 10, color: T.textMute, marginTop: 8, fontFamily: T.mono, textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700 }}>{s.label}</div>
                </GlassCard>
              </StaggerItem>
            ))}
          </div>
        </div>

        {/* Recent PRs */}
        <div style={{ marginBottom: 22 }}>
          <SectionLabel right={<SpringButton onClick={() => onNavigate('progress')} style={{
            padding: 0, background: 'transparent', color: T.accent,
            fontSize: 11, fontWeight: 700, fontFamily: T.mono, letterSpacing: '0.08em',
          }}>ALLE PR'S →</SpringButton>}>Recente PR's</SectionLabel>
          <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { name: 'Barbell Bench Press', weight: 92.5, delta: '+2.5', date: '23 apr' },
              { name: 'Deadlift', weight: 140, delta: '+5', date: '18 apr' },
              { name: 'Barbell Squat', weight: 115, delta: '+2.5', date: '15 apr' },
            ].map((pr, i) => (
              <StaggerItem key={i} delay={500 + i * 70}>
                <GlassCard style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 12 }} onClick={() => onNavigate('exercise-detail')}>
                  <div style={{
                    width: 40, height: 40, borderRadius: 12,
                    background: 'rgba(62,232,168,0.12)',
                    border: '1px solid rgba(62,232,168,0.25)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    boxShadow: '0 4px 12px rgba(62,232,168,0.25)',
                  }}>
                    <Icon name="trend-up" size={16} color={T.success} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600 }}>{pr.name}</div>
                    <div style={{ fontSize: 11, color: T.textMute, fontFamily: T.mono, marginTop: 3 }}>
                      {pr.date} · <span style={{ color: T.success, fontWeight: 600 }}>{pr.delta} kg</span>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontFamily: T.display, fontSize: 22, fontWeight: 700, lineHeight: 1 }}>{pr.weight}</div>
                    <div style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute, marginTop: 3, letterSpacing: '0.08em' }}>KG</div>
                  </div>
                </GlassCard>
              </StaggerItem>
            ))}
          </div>
        </div>
      </ScrollArea>
      <BottomNav active="home" onSelect={onNavigate} />
    </ScreenShell>
  );
};

/* ========== ACTIVE WORKOUT ========== */
const WorkoutScreen = ({ onNavigate = () => {} }) => {
  const T = useTheme();
  const [exercises, setExercises] = React.useState([
    { id: 'bench', name: 'Barbell Bench Press', muscle: 'Borst',
      sets: [{ w: 80, r: 10, done: true }, { w: 82.5, r: 8, done: true }, { w: 85, r: 6, done: false, active: true }],
      last: '80 × 10 · 14 apr' },
    { id: 'ohp', name: 'Dumbbell Shoulder Press', muscle: 'Schouder',
      sets: [{ w: 22.5, r: 10, done: false }, { w: 22.5, r: 10, done: false }, { w: 22.5, r: 10, done: false }],
      last: '22.5 × 10 · 14 apr' },
    { id: 'fly', name: 'Chest Fly (Dumbbell)', muscle: 'Borst',
      sets: [{ w: 14, r: 12, done: false }, { w: 14, r: 12, done: false }, { w: 14, r: 12, done: false }],
      last: '14 × 12 · 14 apr' },
  ]);
  const [expanded, setExpanded] = React.useState('bench');
  const [time, setTime] = React.useState(18 * 60 + 42);

  React.useEffect(() => {
    const t = setInterval(() => setTime(s => s + 1), 1000);
    return () => clearInterval(t);
  }, []);
  const fmt = s => `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toString().padStart(2,'0')}`;

  const toggleSet = (exId, setIdx) => {
    setExercises(prev => prev.map(e => {
      if (e.id !== exId) return e;
      const sets = e.sets.map((s, i) => i === setIdx ? { ...s, done: !s.done, active: false } : s);
      return { ...e, sets };
    }));
  };

  const totalSets = exercises.reduce((a, e) => a + e.sets.length, 0);
  const doneSets = exercises.reduce((a, e) => a + e.sets.filter(s => s.done).length, 0);
  const progress = doneSets / totalSets;

  return (
    <ScreenShell bgIntensity={1.3}>
      {/* Sticky glass top bar */}
      <div style={{
        padding: '54px 16px 14px',
        background: 'rgba(6,6,10,0.72)',
        backdropFilter: 'blur(24px) saturate(180%)',
        WebkitBackdropFilter: 'blur(24px) saturate(180%)',
        borderBottom: `1px solid ${T.glassBorder}`,
        position: 'relative', zIndex: 5,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <SpringButton onClick={() => onNavigate('home')} style={iconBtn(T)}><Icon name="chevron-left" size={20} color={T.text} /></SpringButton>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 9.5, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.16em', textTransform: 'uppercase', fontWeight: 700 }}>Push Day</div>
            <div style={{ fontFamily: T.mono, fontSize: 22, fontWeight: 700, marginTop: 2, color: T.accent, letterSpacing: '0.04em', textShadow: `0 0 20px ${T.accentGlow}` }}>{fmt(time)}</div>
          </div>
          <SpringButton style={iconBtn(T)}><Icon name="dots" size={20} color={T.text} /></SpringButton>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ flex: 1, height: 5, borderRadius: 3, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
            <div style={{
              width: `${progress * 100}%`, height: '100%',
              background: T.accentGrad,
              boxShadow: `0 0 12px ${T.accentGlow}`,
              transition: 'width 0.5s cubic-bezier(.2,.8,.2,1)',
              borderRadius: 3,
            }} />
          </div>
          <div style={{ fontSize: 11, fontFamily: T.mono, color: T.text, fontWeight: 700 }}>{doneSets}<span style={{ color: T.textMute }}>/{totalSets}</span></div>
        </div>
      </div>

      <ScrollArea style={{ paddingBottom: 150 }}>
        <div style={{ padding: '16px 14px 4px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {exercises.map((ex, i) => {
            const isOpen = expanded === ex.id;
            const doneCount = ex.sets.filter(s => s.done).length;
            const allDone = doneCount === ex.sets.length;
            return (
              <StaggerItem key={ex.id} delay={80 + i * 80}>
                <GlassCard style={{ padding: 0, overflow: 'hidden',
                  border: `1px solid ${allDone ? 'rgba(62,232,168,0.3)' : T.glassBorder}`,
                  boxShadow: allDone ? '0 8px 28px rgba(62,232,168,0.15)' : '0 8px 32px rgba(0,0,0,0.35)',
                }}>
                  <SpringButton onClick={() => setExpanded(isOpen ? null : ex.id)} pressScale={0.99} style={{
                    width: '100%', padding: '14px 16px',
                    background: 'transparent', color: T.text, textAlign: 'left',
                    display: 'flex', alignItems: 'center', gap: 12,
                  }}>
                    <div style={{
                      width: 40, height: 40, borderRadius: 12,
                      background: allDone ? 'rgba(62,232,168,0.14)' : 'rgba(255,255,255,0.06)',
                      border: `1px solid ${allDone ? 'rgba(62,232,168,0.3)' : T.glassBorder}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      {allDone
                        ? <Icon name="check" size={17} color={T.success} stroke={2.5} />
                        : <span style={{ fontFamily: T.mono, fontSize: 13, fontWeight: 700, color: T.textDim }}>{String(i+1).padStart(2,'0')}</span>}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 14.5, fontWeight: 600 }}>{ex.name}</div>
                      <div style={{ fontSize: 11, color: T.textMute, fontFamily: T.mono, marginTop: 3, letterSpacing: '0.04em' }}>
                        {doneCount}/{ex.sets.length} SETS · last: {ex.last}
                      </div>
                    </div>
                    <div style={{ transition: 'transform 0.3s cubic-bezier(.2,.8,.2,1)', transform: isOpen ? 'rotate(180deg)' : 'rotate(0)' }}>
                      <Icon name="chevron-down" size={18} color={T.textDim} />
                    </div>
                  </SpringButton>

                  <div style={{
                    maxHeight: isOpen ? 600 : 0,
                    overflow: 'hidden',
                    transition: 'max-height 0.4s cubic-bezier(.2,.8,.2,1)',
                  }}>
                    <div style={{ padding: '2px 14px 14px', borderTop: `1px solid ${T.glassBorder}` }}>
                      <div style={{ display: 'grid', gridTemplateColumns: '28px 1fr 1fr 44px', gap: 8, padding: '12px 4px 8px', fontSize: 9, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 700 }}>
                        <div>SET</div><div>KG</div><div>REPS</div><div style={{ textAlign: 'center' }}>✓</div>
                      </div>
                      {ex.sets.map((s, si) => (
                        <SetRow key={si} setNum={si+1} set={s} onToggle={() => toggleSet(ex.id, si)} T={T} />
                      ))}
                      <SpringButton style={{
                        width: '100%', marginTop: 10, padding: 12,
                        border: `1px dashed ${T.glassBorderHi}`,
                        background: 'transparent', color: T.textDim, borderRadius: 12,
                        fontSize: 12, fontWeight: 500,
                        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                      }}><Icon name="plus" size={13} color={T.textDim} /> Set toevoegen</SpringButton>
                    </div>
                  </div>
                </GlassCard>
              </StaggerItem>
            );
          })}

          <SpringButton style={{
            width: '100%', marginTop: 6, padding: 16,
            border: `1px dashed ${T.glassBorder}`,
            background: T.glass, color: T.textDim, borderRadius: 16,
            backdropFilter: 'blur(20px)',
            fontSize: 13, fontWeight: 500,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}><Icon name="plus" size={14} color={T.textDim} /> Oefening toevoegen</SpringButton>
        </div>
      </ScrollArea>

      {/* Floating finish */}
      <div style={{ position: 'absolute', left: 14, right: 14, bottom: 22, zIndex: 10 }}>
        <SpringButton onClick={() => onNavigate('home')} style={{
          width: '100%', padding: 18,
          background: T.accentGrad, color: 'white', borderRadius: 18,
          fontSize: 14, fontWeight: 700, letterSpacing: '0.03em',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10,
          boxShadow: `0 16px 40px ${T.accentGlow}, inset 0 1px 0 rgba(255,255,255,0.3)`,
        }}>
          <span style={{ fontFamily: T.mono, fontWeight: 700, fontSize: 11, opacity: 0.9, letterSpacing: '0.08em' }}>{doneSets}/{totalSets} SETS</span>
          <span>TRAINING AFRONDEN</span>
          <Icon name="arrow-right" size={16} color="white" stroke={2.5} />
        </SpringButton>
      </div>
    </ScreenShell>
  );
};

const SetRow = ({ setNum, set, onToggle, T }) => (
  <div style={{
    display: 'grid', gridTemplateColumns: '28px 1fr 1fr 44px', gap: 8,
    padding: '8px 4px', alignItems: 'center',
    background: set.done ? 'rgba(62,232,168,0.06)' : 'transparent',
    borderRadius: 10, marginBottom: 4,
    transition: 'background 0.25s',
  }}>
    <div style={{ fontFamily: T.mono, fontSize: 13, fontWeight: 700, color: set.done ? T.success : T.textDim, textAlign: 'center' }}>{setNum}</div>
    <div style={{
      background: 'rgba(255,255,255,0.04)',
      padding: '9px 10px', borderRadius: 10,
      fontFamily: T.mono, fontSize: 14, fontWeight: 600,
      color: set.done ? T.textDim : T.text,
      border: `1px solid ${set.active ? T.accent : T.glassBorder}`,
      boxShadow: set.active ? `0 0 16px ${T.accentGlow}` : 'none',
    }}>{set.w} <span style={{ fontSize: 10, color: T.textMute, fontWeight: 500 }}>kg</span></div>
    <div style={{
      background: 'rgba(255,255,255,0.04)',
      padding: '9px 10px', borderRadius: 10,
      fontFamily: T.mono, fontSize: 14, fontWeight: 600,
      color: set.done ? T.textDim : T.text,
      border: `1px solid ${set.active ? T.accent : T.glassBorder}`,
    }}>{set.r}</div>
    <SpringButton onClick={onToggle} pressScale={0.85} style={{
      width: 32, height: 32, borderRadius: 10,
      background: set.done ? `linear-gradient(135deg, ${T.success}, #2fd093)` : 'rgba(255,255,255,0.05)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto',
      boxShadow: set.done ? '0 6px 16px rgba(62,232,168,0.35)' : 'none',
      border: set.done ? 'none' : `1px solid ${T.glassBorder}`,
    }}><Icon name="check" size={16} color={set.done ? '#052b1c' : T.textMute} stroke={2.5} /></SpringButton>
  </div>
);

/* ========== PROGRESS (3D FIGURE HERO) ========== */
const ProgressScreen = ({ onNavigate = () => {} }) => {
  const T = useTheme();
  const [selectedMuscle, setSelectedMuscle] = React.useState(null);
  const muscle = selectedMuscle ? MUSCLE_DEFS[selectedMuscle] : null;

  const weeks = [4200, 5100, 5800, 5300, 6200, 7100, 6800, 7400];
  const maxW = Math.max(...weeks);

  return (
    <ScreenShell bgIntensity={1.5}>
      <ScrollArea style={{ paddingBottom: 130 }}>
        <StatusSpacer />

        {/* Header */}
        <div style={{ padding: '8px 20px 12px' }}>
          <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.16em', textTransform: 'uppercase', fontWeight: 700 }}>Overzicht</div>
          <div style={{ fontFamily: T.display, fontSize: 34, fontWeight: 700, letterSpacing: '-0.03em', marginTop: 4 }}>Progress</div>
          <div style={{ fontSize: 12, color: T.textDim, marginTop: 4 }}>Tik een spier · draai om te verkennen</div>
        </div>

        {/* 3D Figure hero card */}
        <div style={{ padding: '0 14px', marginBottom: 14 }}>
          <GlassCard hi style={{ padding: 0, overflow: 'hidden', position: 'relative', height: 440 }}>
            <ParticleField count={18} />
            {/* corner labels */}
            <div style={{
              position: 'absolute', top: 14, left: 14, zIndex: 3,
              fontSize: 9, fontFamily: T.mono, color: T.textMute,
              letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 700,
            }}>3D Anatomy</div>
            <div style={{
              position: 'absolute', top: 14, right: 14, zIndex: 3,
              display: 'flex', alignItems: 'center', gap: 6,
              fontSize: 9, fontFamily: T.mono, color: T.textDim,
              letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 600,
            }}>
              <Icon name="rotate" size={11} color={T.textDim} /> DRAG
            </div>

            <MuscleFigure
              selectedMuscle={selectedMuscle}
              onSelect={setSelectedMuscle}
              height={440}
            />

            {/* bottom overlay — muscle info card */}
            {muscle && (
              <div style={{
                position: 'absolute', left: 14, right: 14, bottom: 14, zIndex: 4,
                padding: 14,
                background: `linear-gradient(135deg, ${muscle.color}22, rgba(12,12,18,0.8))`,
                backdropFilter: 'blur(24px) saturate(180%)',
                WebkitBackdropFilter: 'blur(24px) saturate(180%)',
                border: `1px solid ${muscle.color}55`,
                borderRadius: 18,
                boxShadow: `0 12px 36px ${muscle.color}33, inset 0 1px 0 rgba(255,255,255,0.12)`,
                animation: 'slideUpFade 0.4s cubic-bezier(.2,.8,.2,1)',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ width: 6, height: 6, borderRadius: '50%', background: muscle.color, boxShadow: `0 0 12px ${muscle.color}` }} />
                    <div style={{ fontFamily: T.display, fontSize: 18, fontWeight: 700, letterSpacing: '-0.02em' }}>{muscle.label}</div>
                  </div>
                  <SpringButton onClick={() => setSelectedMuscle(null)} pressScale={0.88} style={{
                    width: 28, height: 28, borderRadius: 9, background: 'rgba(255,255,255,0.08)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    border: `1px solid ${T.glassBorder}`, color: T.textDim,
                  }}><Icon name="x" size={14} color={T.textDim} stroke={2.2} /></SpringButton>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
                  <MuscleStat label="Volume" value={muscle.stats.volume} T={T} />
                  <MuscleStat label="PR" value={muscle.stats.pr} T={T} accent={muscle.color} />
                  <MuscleStat label="Freq" value={muscle.stats.freq} T={T} />
                </div>
              </div>
            )}
          </GlassCard>
        </div>

        {/* Muscle chip strip */}
        <div style={{ marginBottom: 22 }}>
          <div style={{
            padding: '8px 14px 4px', display: 'flex', gap: 6,
            overflowX: 'auto',
          }} className="hide-scrollbar">
            {Object.entries(MUSCLE_DEFS).map(([key, def]) => {
              const isActive = selectedMuscle === key;
              return (
                <SpringButton key={key} onClick={() => setSelectedMuscle(isActive ? null : key)} pressScale={0.94} style={{
                  flexShrink: 0, padding: '8px 12px',
                  background: isActive ? `${def.color}33` : 'rgba(255,255,255,0.04)',
                  color: isActive ? def.color : T.textDim,
                  borderRadius: 999,
                  border: `1px solid ${isActive ? def.color : T.glassBorder}`,
                  fontSize: 11, fontWeight: 700, letterSpacing: '0.04em',
                  backdropFilter: 'blur(14px)',
                  boxShadow: isActive ? `0 4px 14px ${def.color}44` : 'none',
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  <div style={{ width: 5, height: 5, borderRadius: '50%', background: def.color, boxShadow: isActive ? `0 0 8px ${def.color}` : 'none' }} />
                  {def.label}
                </SpringButton>
              );
            })}
          </div>
        </div>

        {/* Time filter */}
        <div style={{ padding: '0 20px', display: 'flex', gap: 4, marginBottom: 16 }}>
          {['4W','8W','3M','6M','1Y','ALL'].map((t, i) => (
            <SpringButton key={t} pressScale={0.94} style={{
              flex: 1, padding: '8px 0',
              background: i === 1 ? T.accentGrad : 'rgba(255,255,255,0.05)',
              color: i === 1 ? 'white' : T.textDim,
              borderRadius: 10, border: `1px solid ${i === 1 ? T.accent : T.glassBorder}`,
              fontSize: 10.5, fontFamily: T.mono, fontWeight: 700, letterSpacing: '0.1em',
              boxShadow: i === 1 ? `0 6px 18px ${T.accentGlow}` : 'none',
            }}>{t}</SpringButton>
          ))}
        </div>

        {/* Volume chart */}
        <div style={{ padding: '0 14px', marginBottom: 22 }}>
          <GlassCard style={{ padding: 18 }}>
            <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 4 }}>
              <div>
                <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 700 }}>Weekly volume</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 6 }}>
                  <span style={{ fontFamily: T.display, fontSize: 32, fontWeight: 700, letterSpacing: '-0.03em' }}>
                    <TickerNumber value={7400} />
                  </span>
                  <span style={{ fontSize: 12, color: T.textMute, fontFamily: T.mono }}>kg</span>
                </div>
              </div>
              <GlassPill tone="success"><Icon name="arrow-up" size={9} color={T.success} stroke={3} />+8.8%</GlassPill>
            </div>
            <div style={{ height: 130, display: 'flex', alignItems: 'flex-end', gap: 8, marginTop: 18 }}>
              {weeks.map((w, i) => {
                const isLast = i === weeks.length - 1;
                return (
                  <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                    <div style={{
                      width: '100%',
                      height: `${(w/maxW) * 100}%`,
                      background: isLast ? T.accentGrad : 'rgba(255,255,255,0.08)',
                      borderRadius: 5,
                      border: isLast ? 'none' : `1px solid ${T.glassBorder}`,
                      boxShadow: isLast ? `0 0 16px ${T.accentGlow}` : 'none',
                      transition: 'all 0.6s cubic-bezier(.2,.8,.2,1)',
                      animation: `barRise ${0.6 + i * 0.08}s cubic-bezier(.2,.8,.2,1)`,
                      transformOrigin: 'bottom',
                    }} />
                    <div style={{ fontSize: 9, fontFamily: T.mono, color: isLast ? T.accent : T.textMute, fontWeight: 600 }}>W{i+15}</div>
                  </div>
                );
              })}
            </div>
          </GlassCard>
        </div>
      </ScrollArea>
      <BottomNav active="progress" onSelect={onNavigate} />
    </ScreenShell>
  );
};

const MuscleStat = ({ label, value, T, accent }) => (
  <div style={{
    padding: 10, borderRadius: 12,
    background: 'rgba(0,0,0,0.3)',
    border: `1px solid ${T.glassBorder}`,
  }}>
    <div style={{ fontSize: 8.5, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 700 }}>{label}</div>
    <div style={{ fontFamily: T.display, fontSize: 15, fontWeight: 700, marginTop: 5, letterSpacing: '-0.02em', color: accent || T.text }}>{value}</div>
  </div>
);

const iconBtn = (T) => ({
  width: 40, height: 40, borderRadius: 12,
  background: T.glass,
  backdropFilter: 'blur(14px)',
  border: `1px solid ${T.glassBorder}`,
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  color: T.text,
});

Object.assign(window, { DashboardScreen, WorkoutScreen, ProgressScreen, BottomNav, ScreenShell, ScrollArea, iconBtn });
