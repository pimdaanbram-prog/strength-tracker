/* ============================================================
   SECONDARY SCREENS — Exercise Detail, Library, History, Settings
   ============================================================ */

const ExerciseDetailScreen = ({ onNavigate = () => {} }) => {
  const T = useTheme();
  const history = [82.5, 85, 85, 87.5, 87.5, 90, 90, 92.5];
  const maxH = Math.max(...history); const minH = Math.min(...history);

  return (
    <ScreenShell bgIntensity={1.2}>
      <ScrollArea style={{ paddingBottom: 40 }}>
        {/* Hero */}
        <div style={{ paddingTop: 54, paddingBottom: 26, position: 'relative' }}>
          <div style={{ position: 'absolute', top: -40, right: -40, width: 240, height: 240,
            background: `radial-gradient(circle, ${T.accent}55, transparent 70%)`, filter: 'blur(40px)' }} />
          <div style={{ padding: '0 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24, position: 'relative' }}>
            <SpringButton onClick={() => onNavigate('home')} style={iconBtn(T)}><Icon name="chevron-left" size={20} color={T.text} /></SpringButton>
            <SpringButton style={iconBtn(T)}><Icon name="bookmark" size={18} color={T.text} /></SpringButton>
          </div>
          <div style={{ padding: '0 20px', position: 'relative' }}>
            <GlassPill tone="accent" style={{ marginBottom: 12 }}>Borst · Compound</GlassPill>
            <div style={{ fontFamily: T.display, fontSize: 32, fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1.05 }}>Barbell Bench Press</div>
            <div style={{ fontSize: 12.5, color: T.textDim, marginTop: 8 }}>Borst · Voorste deltoid · Triceps</div>
          </div>
        </div>

        <div style={{ padding: '0 14px', marginTop: -8, marginBottom: 22, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
          {[
            { lbl: 'PR', val: 92.5, sub: 'KG', accent: T.success, dec: 1 },
            { lbl: 'Last', val: 90, sub: '× 8 REPS', dec: 0 },
            { lbl: 'Sets', val: 127, sub: 'LIFETIME', dec: 0 },
          ].map((s, i) => (
            <StaggerItem key={i} delay={60 + i * 60}>
              <GlassCard style={{ padding: '14px 10px', textAlign: 'center' }}>
                <div style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute, textTransform: 'uppercase', letterSpacing: '0.14em', fontWeight: 700 }}>{s.lbl}</div>
                <div style={{ fontFamily: T.display, fontSize: 24, fontWeight: 700, color: s.accent || T.text, marginTop: 6, letterSpacing: '-0.03em' }}>
                  <TickerNumber value={s.val} decimals={s.dec} />
                </div>
                <div style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute, marginTop: 3, letterSpacing: '0.08em' }}>{s.sub}</div>
              </GlassCard>
            </StaggerItem>
          ))}
        </div>

        <div style={{ padding: '0 14px', marginBottom: 22 }}>
          <GlassCard style={{ padding: 18 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 700 }}>Progressie · Top set</div>
              <GlassPill tone="success">+12%</GlassPill>
            </div>
            <svg viewBox="0 0 320 100" style={{ width: '100%', height: 100 }}>
              <defs>
                <linearGradient id="ed-g" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={T.accent} stopOpacity="0.4" />
                  <stop offset="100%" stopColor={T.accent} stopOpacity="0" />
                </linearGradient>
              </defs>
              {(() => {
                const pts = history.map((v, i) => [(i / (history.length - 1)) * 320, 100 - ((v - minH) / (maxH - minH || 1)) * 78 - 8]);
                const d = pts.map((p,i) => `${i===0?'M':'L'}${p[0]},${p[1]}`).join(' ');
                return (<g>
                  <path d={`${d} L320,100 L0,100 Z`} fill="url(#ed-g)" />
                  <path d={d} fill="none" stroke={T.accent} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ filter: `drop-shadow(0 0 6px ${T.accent})` }} />
                  {pts.map(([x,y],i) => <circle key={i} cx={x} cy={y} r={i===pts.length-1 ? 5 : 2.5} fill={i===pts.length-1 ? T.accent : '#16161A'} stroke={T.accent} strokeWidth={i===pts.length-1?0:1.5} />)}
                </g>);
              })()}
            </svg>
          </GlassCard>
        </div>

        <SectionLabel>Historie</SectionLabel>
        <div style={{ padding: '0 14px', display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 24 }}>
          {[
            { date: '23 apr', sets: '80×10 · 82.5×8 · 85×6', pr: false, best: 85 },
            { date: '18 apr', sets: '80×10 · 82.5×9 · 85×5', pr: false, best: 85 },
            { date: '14 apr', sets: '80×10 · 85×8 · 87.5×6', pr: true, best: 92.5 },
            { date: '11 apr', sets: '77.5×10 · 80×8 · 82.5×6', pr: false, best: 82.5 },
          ].map((h, i) => (
            <StaggerItem key={i} delay={100 + i * 60}>
              <GlassCard style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 4, alignSelf: 'stretch', background: h.pr ? T.success : T.glassBorder, borderRadius: 2, boxShadow: h.pr ? '0 0 8px rgba(62,232,168,0.5)' : 'none' }} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 600 }}>{h.date}</div>
                    {h.pr && <GlassPill tone="success">PR</GlassPill>}
                  </div>
                  <div style={{ fontSize: 11, color: T.textMute, fontFamily: T.mono, marginTop: 4 }}>{h.sets}</div>
                </div>
                <div style={{ textAlign: 'right', fontFamily: T.mono }}>
                  <div style={{ fontSize: 15, fontWeight: 700 }}>{h.best}</div>
                  <div style={{ fontSize: 9, color: T.textMute, marginTop: 2, letterSpacing: '0.08em' }}>TOP KG</div>
                </div>
              </GlassCard>
            </StaggerItem>
          ))}
        </div>
      </ScrollArea>
    </ScreenShell>
  );
};

const ExercisesScreen = ({ onNavigate = () => {} }) => {
  const T = useTheme();
  const cats = ['Alle', 'Borst', 'Rug', 'Benen', 'Schouder', 'Armen', 'Core'];
  const [active, setActive] = React.useState('Alle');
  const list = [
    { n: 'Barbell Bench Press', m: 'Borst', diff: 'Inter', pr: 92.5, done: 127 },
    { n: 'Barbell Squat', m: 'Benen', diff: 'Inter', pr: 115, done: 98 },
    { n: 'Deadlift', m: 'Rug', diff: 'Adv', pr: 140, done: 64 },
    { n: 'Overhead Press', m: 'Schouder', diff: 'Inter', pr: 52.5, done: 72 },
    { n: 'Dumbbell Row', m: 'Rug', diff: 'Begin', pr: 32, done: 81 },
    { n: 'Bicep Curls', m: 'Armen', diff: 'Begin', pr: 16, done: 110 },
  ];

  return (
    <ScreenShell>
      <div style={{
        padding: '54px 16px 14px',
        background: 'rgba(6,6,10,0.6)',
        backdropFilter: 'blur(20px) saturate(180%)',
        WebkitBackdropFilter: 'blur(20px) saturate(180%)',
        position: 'relative', zIndex: 5,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 700 }}>Library</div>
            <div style={{ fontFamily: T.display, fontSize: 28, fontWeight: 700, letterSpacing: '-0.03em', marginTop: 4 }}>Oefeningen</div>
          </div>
          <SpringButton style={iconBtn(T)}><Icon name="filter" size={18} color={T.text} /></SpringButton>
        </div>
        <GlassCard style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', borderRadius: 14 }}>
          <Icon name="search" size={15} color={T.textDim} />
          <input placeholder="Zoek oefening…" style={{
            flex: 1, border: 'none', background: 'transparent',
            color: T.text, outline: 'none', fontSize: 13,
          }} />
          <span style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute, padding: '3px 7px', background: 'rgba(255,255,255,0.06)', borderRadius: 5, border: `1px solid ${T.glassBorder}` }}>56</span>
        </GlassCard>
      </div>

      <div style={{ padding: '12px 16px 4px', display: 'flex', gap: 6, overflowX: 'auto' }} className="hide-scrollbar">
        {cats.map(c => (
          <SpringButton key={c} onClick={() => setActive(c)} pressScale={0.94} style={{
            padding: '8px 14px', borderRadius: 999,
            background: active === c ? T.accentGrad : 'rgba(255,255,255,0.04)',
            color: active === c ? 'white' : T.textDim,
            fontSize: 12, fontWeight: 700, whiteSpace: 'nowrap',
            border: `1px solid ${active === c ? T.accent : T.glassBorder}`,
            boxShadow: active === c ? `0 4px 14px ${T.accentGlow}` : 'none',
          }}>{c}</SpringButton>
        ))}
      </div>

      <ScrollArea style={{ paddingBottom: 130 }}>
        <div style={{ padding: '14px 14px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          {list.map((e, i) => (
            <StaggerItem key={i} delay={60 + i * 50}>
              <GlassCard onClick={() => onNavigate('exercise-detail')} style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{
                  width: 50, height: 50, borderRadius: 14,
                  background: `linear-gradient(135deg, ${T.accent}22, rgba(255,255,255,0.04))`,
                  border: `1px solid ${T.glassBorder}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Icon name="dumbbell" size={20} color={T.accent} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600 }}>{e.n}</div>
                  <div style={{ fontSize: 10, color: T.textMute, fontFamily: T.mono, marginTop: 4, display: 'flex', gap: 8, letterSpacing: '0.05em' }}>
                    <span>{e.m.toUpperCase()}</span><span>·</span><span>{e.diff.toUpperCase()}</span><span>·</span><span>{e.done}× DONE</span>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: T.display, fontSize: 16, fontWeight: 700, color: T.success }}>{e.pr}</div>
                  <div style={{ fontSize: 9, color: T.textMute, fontFamily: T.mono, marginTop: 2, letterSpacing: '0.08em' }}>PR · KG</div>
                </div>
              </GlassCard>
            </StaggerItem>
          ))}
        </div>
      </ScrollArea>
      <BottomNav active="workout" onSelect={onNavigate} />
    </ScreenShell>
  );
};

const HistoryScreen = ({ onNavigate = () => {} }) => {
  const T = useTheme();
  const days = Array.from({ length: 35 }, (_, i) => [0,0,1,0,2,3,0,0,1,2,0,3,0,2,1,0,0,2,3,1,0,0,1,2,0,3,2,0,1,0,2,3,1,0,0][i] ?? 0);

  return (
    <ScreenShell>
      <ScrollArea style={{ paddingBottom: 130 }}>
        <StatusSpacer />
        <div style={{ padding: '8px 20px 18px' }}>
          <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 700 }}>Historie</div>
          <div style={{ fontFamily: T.display, fontSize: 30, fontWeight: 700, letterSpacing: '-0.03em', marginTop: 4 }}>April 2026</div>
        </div>

        <div style={{ padding: '0 14px', marginBottom: 22 }}>
          <StaggerItem delay={80}>
            <GlassCard hi style={{ padding: 18 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
                <div>
                  <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.12em', textTransform: 'uppercase', fontWeight: 700 }}>Activiteit</div>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 6 }}>
                    <span style={{ fontFamily: T.display, fontSize: 26, fontWeight: 700, letterSpacing: '-0.03em' }}><TickerNumber value={14} /></span>
                    <span style={{ fontSize: 11, color: T.textMute, fontFamily: T.mono }}>trainingen</span>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 10px', background: 'rgba(255,176,32,0.12)', border: '1px solid rgba(255,176,32,0.25)', borderRadius: 999 }}>
                  <Icon name="flame" size={13} color={T.warning} />
                  <span style={{ fontFamily: T.mono, fontWeight: 700, fontSize: 12, color: T.warning }}>12d</span>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 5, marginBottom: 6 }}>
                {['M','D','W','D','V','Z','Z'].map((d,i) => (
                  <div key={i} style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute, textAlign: 'center', fontWeight: 700 }}>{d}</div>
                ))}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 5 }}>
                {days.map((v, i) => {
                  const bg = v === 0 ? 'rgba(255,255,255,0.04)'
                    : v === 1 ? `${T.accent}44`
                    : v === 2 ? `${T.accent}88`
                    : T.accent;
                  return (
                    <div key={i} style={{
                      aspectRatio: '1', borderRadius: 6,
                      background: bg,
                      border: `1px solid ${v === 0 ? T.glassBorder : 'transparent'}`,
                      boxShadow: v === 3 ? `0 0 8px ${T.accentGlow}` : 'none',
                      animation: `heatIn 0.4s cubic-bezier(.2,.8,.2,1) ${i * 0.015}s both`,
                    }} />
                  );
                })}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'flex-end', marginTop: 14 }}>
                <span style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute }}>Minder</span>
                {[0,1,2,3].map(v => {
                  const bg = v === 0 ? 'rgba(255,255,255,0.04)' : v === 1 ? `${T.accent}44` : v === 2 ? `${T.accent}88` : T.accent;
                  return <div key={v} style={{ width: 12, height: 12, borderRadius: 3, background: bg, border: `1px solid ${v===0?T.glassBorder:'transparent'}` }} />;
                })}
                <span style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute }}>Meer</span>
              </div>
            </GlassCard>
          </StaggerItem>
        </div>

        <SectionLabel>Recente trainingen</SectionLabel>
        <div style={{ padding: '0 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[
            { date: '23', day: 'Do', name: 'Push Day', d: 48, ex: 5, pr: 1, prs: ['Bench +2.5'] },
            { date: '21', day: 'Di', name: 'Pull Day', d: 52, ex: 6, pr: 0, prs: [] },
            { date: '19', day: 'Zo', name: 'Leg Day', d: 64, ex: 7, pr: 1, prs: ['Squat +2.5'] },
            { date: '17', day: 'Vr', name: 'Push Day', d: 45, ex: 5, pr: 0, prs: [] },
          ].map((s, i) => (
            <StaggerItem key={i} delay={180 + i * 70}>
              <GlassCard style={{ padding: 14, display: 'flex', gap: 12 }}>
                <div style={{
                  display: 'flex', flexDirection: 'column',
                  alignItems: 'center', justifyContent: 'center',
                  minWidth: 54, padding: '10px 6px', borderRadius: 12,
                  background: 'rgba(255,255,255,0.04)', border: `1px solid ${T.glassBorder}`,
                }}>
                  <div style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute, textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700 }}>APR</div>
                  <div style={{ fontFamily: T.display, fontSize: 22, fontWeight: 700, lineHeight: 1, marginTop: 3 }}>{s.date}</div>
                  <div style={{ fontSize: 9, fontFamily: T.mono, color: T.textMute, marginTop: 5, fontWeight: 600, letterSpacing: '0.06em' }}>{s.day.toUpperCase()}</div>
                </div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{s.name}</div>
                    {s.pr > 0 && <GlassPill tone="success">+{s.pr} PR</GlassPill>}
                  </div>
                  <div style={{ display: 'flex', gap: 14, fontSize: 11, fontFamily: T.mono, color: T.textDim }}>
                    <span><Icon name="clock" size={10} color={T.textMute} /> {s.d} min</span>
                    <span>{s.ex} oef.</span>
                  </div>
                  {s.prs.length > 0 && <div style={{ fontSize: 10, fontFamily: T.mono, color: T.success, marginTop: 6, fontWeight: 600 }}>{s.prs.join(' · ')}</div>}
                </div>
                <Icon name="chevron-right" size={16} color={T.textMute} />
              </GlassCard>
            </StaggerItem>
          ))}
        </div>
      </ScrollArea>
      <BottomNav active="history" onSelect={onNavigate} />
    </ScreenShell>
  );
};

/* ========== SETTINGS — with live accent picker ========== */
const SettingsScreen = ({ onNavigate = () => {} }) => {
  const T = useTheme();
  return (
    <ScreenShell bgIntensity={1.4}>
      <ScrollArea style={{ paddingBottom: 130 }}>
        <StatusSpacer />
        <div style={{ padding: '8px 20px 24px' }}>
          <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 700 }}>Instellingen</div>
          <div style={{ fontFamily: T.display, fontSize: 30, fontWeight: 700, letterSpacing: '-0.03em', marginTop: 4 }}>Jouw vibe</div>
        </div>

        {/* Profile card */}
        <div style={{ padding: '0 14px', marginBottom: 22 }}>
          <StaggerItem delay={80}>
            <GlassCard hi style={{ padding: 18, display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{
                width: 56, height: 56, borderRadius: 18,
                background: T.accentGrad,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: T.display, fontWeight: 800, fontSize: 22, color: 'white',
                boxShadow: `0 10px 28px ${T.accentGlow}, inset 0 1px 0 rgba(255,255,255,0.3)`,
              }}>P</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 16, fontWeight: 600 }}>Pim</div>
                <div style={{ fontSize: 11, color: T.textMute, fontFamily: T.mono, marginTop: 3 }}>Member sinds jan 2024 · 248 sessions</div>
              </div>
              <Icon name="chevron-right" size={18} color={T.textDim} />
            </GlassCard>
          </StaggerItem>
        </div>

        {/* Accent picker — the main event */}
        <SectionLabel right={<div style={{ fontSize: 10, fontFamily: T.mono, color: T.accent, fontWeight: 700, letterSpacing: '0.1em' }}>{T.accentName.toUpperCase()}</div>}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icon name="palette" size={11} color={T.textDim} /> Accent kleur
          </span>
        </SectionLabel>
        <div style={{ padding: '0 14px', marginBottom: 22 }}>
          <StaggerItem delay={160}>
            <GlassCard style={{ padding: 16 }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                {Object.entries(ACCENTS).map(([key, a]) => {
                  const isActive = T.accentKey === key;
                  const grad = `linear-gradient(135deg, ${a.c1}, ${a.c2})`;
                  return (
                    <SpringButton key={key} onClick={() => T.setAccent(key)} pressScale={0.92} style={{
                      position: 'relative',
                      padding: '14px 10px',
                      background: isActive ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.03)',
                      border: `1.5px solid ${isActive ? a.c1 : T.glassBorder}`,
                      borderRadius: 16,
                      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                      boxShadow: isActive ? `0 8px 24px ${a.c1}55` : 'none',
                    }}>
                      {isActive && (
                        <div style={{
                          position: 'absolute', top: 6, right: 6,
                          width: 16, height: 16, borderRadius: '50%',
                          background: grad, display: 'flex', alignItems: 'center', justifyContent: 'center',
                          boxShadow: `0 0 10px ${a.c1}`,
                        }}>
                          <Icon name="check" size={9} color="#000" stroke={3} />
                        </div>
                      )}
                      <div style={{
                        width: 40, height: 40, borderRadius: 12,
                        background: grad,
                        boxShadow: `0 8px 20px ${a.c1}66, inset 0 1px 0 rgba(255,255,255,0.4)`,
                      }} />
                      <div style={{ fontSize: 11, fontWeight: 700, color: isActive ? T.text : T.textDim, letterSpacing: '0.02em' }}>{a.name}</div>
                    </SpringButton>
                  );
                })}
              </div>
              <div style={{ marginTop: 16, padding: 12, background: 'rgba(0,0,0,0.3)', borderRadius: 12, border: `1px solid ${T.glassBorder}` }}>
                <div style={{ fontSize: 10, fontFamily: T.mono, color: T.textMute, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 8 }}>Preview</div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <div style={{ flex: 1, height: 36, borderRadius: 10, background: T.accentGrad, boxShadow: `0 6px 16px ${T.accentGlow}` }} />
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: T.accentSoft, border: `1px solid ${T.accent}44`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name="sparkles" size={16} color={T.accent} />
                  </div>
                </div>
              </div>
            </GlassCard>
          </StaggerItem>
        </div>

        {/* Other settings */}
        <SectionLabel>Voorkeuren</SectionLabel>
        <div style={{ padding: '0 14px', marginBottom: 22 }}>
          <StaggerItem delay={240}>
            <GlassCard style={{ padding: 0, overflow: 'hidden' }}>
              {[
                { icon: 'weight', label: 'Eenheden', value: 'Kilogram', color: T.accent },
                { icon: 'bell', label: 'Notificaties', value: 'Aan', color: T.success },
                { icon: 'sparkles', label: 'Animaties', value: 'Max', color: T.warning },
                { icon: 'user', label: 'Account', value: 'Pim', color: T.textDim },
              ].map((item, i) => (
                <div key={i} style={{
                  padding: '14px 16px',
                  display: 'flex', alignItems: 'center', gap: 12,
                  borderBottom: i < 3 ? `1px solid ${T.glassBorder}` : 'none',
                }}>
                  <div style={{
                    width: 34, height: 34, borderRadius: 10,
                    background: 'rgba(255,255,255,0.04)',
                    border: `1px solid ${T.glassBorder}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <Icon name={item.icon} size={15} color={item.color} />
                  </div>
                  <div style={{ flex: 1, fontSize: 13.5, fontWeight: 500 }}>{item.label}</div>
                  <div style={{ fontSize: 12, color: T.textDim, fontFamily: T.mono, fontWeight: 500 }}>{item.value}</div>
                  <Icon name="chevron-right" size={15} color={T.textMute} />
                </div>
              ))}
            </GlassCard>
          </StaggerItem>
        </div>
      </ScrollArea>
      <BottomNav active="settings" onSelect={onNavigate} />
    </ScreenShell>
  );
};

Object.assign(window, { ExerciseDetailScreen, ExercisesScreen, HistoryScreen, SettingsScreen });
