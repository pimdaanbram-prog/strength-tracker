/* ============================================================
   ANIMATION PRIMITIVES — spring hooks, tickers, transitions, ambient bg
   ============================================================ */

// Hook: spring-animate a scalar value
const useSpring = (target, { stiffness = 170, damping = 20, precision = 0.001 } = {}) => {
  const [value, setValue] = React.useState(target);
  const v = React.useRef(target);
  const velRef = React.useRef(0);
  const raf = React.useRef(null);

  React.useEffect(() => {
    const step = () => {
      const force = -stiffness * (v.current - target);
      const dForce = -damping * velRef.current;
      const accel = force + dForce;
      velRef.current += accel * (1/60);
      v.current += velRef.current * (1/60);
      if (Math.abs(velRef.current) < precision && Math.abs(v.current - target) < precision) {
        v.current = target; velRef.current = 0;
        setValue(target);
        return;
      }
      setValue(v.current);
      raf.current = requestAnimationFrame(step);
    };
    raf.current = requestAnimationFrame(step);
    return () => { if (raf.current) cancelAnimationFrame(raf.current); };
  }, [target, stiffness, damping, precision]);
  return value;
};

// Number ticker — tween between values with easing
const TickerNumber = ({ value, decimals = 0, duration = 900, style = {}, suffix = '', prefix = '' }) => {
  const [display, setDisplay] = React.useState(value);
  const fromRef = React.useRef(value);
  React.useEffect(() => {
    const start = performance.now();
    const from = fromRef.current;
    const delta = value - from;
    let raf;
    const step = (now) => {
      const t = Math.min(1, (now - start) / duration);
      // easeOutExpo
      const e = t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
      const cur = from + delta * e;
      setDisplay(cur);
      if (t < 1) raf = requestAnimationFrame(step);
      else fromRef.current = value;
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);
  return <span style={{ fontVariantNumeric: 'tabular-nums', ...style }}>{prefix}{display.toFixed(decimals)}{suffix}</span>;
};

// Staggered-entry list — children animate in with delay
const StaggerList = ({ children, delay = 60, initialDelay = 50, style = {} }) => {
  const items = React.Children.toArray(children);
  return (
    <div style={style}>
      {items.map((child, i) => (
        <StaggerItem key={i} delay={initialDelay + i * delay}>{child}</StaggerItem>
      ))}
    </div>
  );
};

const StaggerItem = ({ children, delay = 0 }) => {
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    const t = setTimeout(() => setShown(true), delay);
    return () => clearTimeout(t);
  }, [delay]);
  return (
    <div style={{
      opacity: shown ? 1 : 0,
      transform: shown ? 'translateY(0) scale(1)' : 'translateY(12px) scale(0.98)',
      transition: 'opacity 0.55s cubic-bezier(.2,.8,.2,1), transform 0.55s cubic-bezier(.2,.8,.2,1)',
    }}>
      {children}
    </div>
  );
};

// SpringButton — press feedback with spring
const SpringButton = ({ children, onClick, style = {}, pressScale = 0.94, ...rest }) => {
  const [down, setDown] = React.useState(false);
  return (
    <button
      onPointerDown={() => setDown(true)}
      onPointerUp={() => setDown(false)}
      onPointerLeave={() => setDown(false)}
      onClick={onClick}
      style={{
        border: 'none', cursor: 'pointer',
        transform: `scale(${down ? pressScale : 1})`,
        transition: 'transform 0.14s cubic-bezier(.2,.8,.2,1)',
        fontFamily: 'inherit',
        ...style,
      }}
      {...rest}
    >{children}</button>
  );
};

// Tilt card — parallax on mouse / touch
const TiltCard = ({ children, style = {}, max = 8, ...rest }) => {
  const ref = React.useRef(null);
  const [tilt, setTilt] = React.useState({ x: 0, y: 0 });
  const onMove = (e) => {
    const r = ref.current.getBoundingClientRect();
    const cx = e.clientX ?? e.touches?.[0]?.clientX;
    const cy = e.clientY ?? e.touches?.[0]?.clientY;
    if (cx == null) return;
    const nx = ((cx - r.left) / r.width - 0.5) * 2;
    const ny = ((cy - r.top) / r.height - 0.5) * 2;
    setTilt({ x: -ny * max, y: nx * max });
  };
  const reset = () => setTilt({ x: 0, y: 0 });
  return (
    <div
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={reset}
      style={{
        transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
        transformStyle: 'preserve-3d',
        transition: 'transform 0.25s cubic-bezier(.2,.8,.2,1)',
        ...style,
      }}
      {...rest}
    >{children}</div>
  );
};

// Page transition wrapper — fade + slide when key changes
const PageTransition = ({ k, direction = 1, children, style = {} }) => {
  const [prev, setPrev] = React.useState(k);
  const [phase, setPhase] = React.useState('in'); // in | out
  const [displayedKey, setDisplayedKey] = React.useState(k);
  const [displayedChildren, setDisplayedChildren] = React.useState(children);

  React.useEffect(() => {
    if (k === displayedKey) {
      setDisplayedChildren(children);
      return;
    }
    // Start out phase
    setPhase('out');
    const t = setTimeout(() => {
      setDisplayedKey(k);
      setDisplayedChildren(children);
      setPhase('in');
    }, 160);
    return () => clearTimeout(t);
  }, [k, children, displayedKey]);

  return (
    <div style={{
      position: 'relative', width: '100%', height: '100%',
      ...style,
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        opacity: phase === 'in' ? 1 : 0,
        transform: phase === 'in' ? 'translateX(0)' : `translateX(${direction * -8}px)`,
        transition: 'opacity 0.3s cubic-bezier(.2,.8,.2,1), transform 0.3s cubic-bezier(.2,.8,.2,1)',
      }}>{displayedChildren}</div>
    </div>
  );
};

// Ambient gradient background — animated, theme-reactive
const AmbientBackground = ({ intensity = 1 }) => {
  const T = useTheme();
  return (
    <div style={{
      position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none', zIndex: 0,
    }}>
      <div style={{
        position: 'absolute', top: '-10%', left: '-10%', width: '60%', height: '60%',
        background: `radial-gradient(circle, ${T.accent}44, transparent 70%)`,
        filter: 'blur(60px)',
        animation: 'orbA 14s ease-in-out infinite',
        opacity: 0.7 * intensity,
      }} />
      <div style={{
        position: 'absolute', bottom: '-15%', right: '-10%', width: '70%', height: '70%',
        background: `radial-gradient(circle, ${T.accentHi}33, transparent 70%)`,
        filter: 'blur(80px)',
        animation: 'orbB 18s ease-in-out infinite',
        opacity: 0.6 * intensity,
      }} />
      <div style={{
        position: 'absolute', top: '30%', right: '-20%', width: '50%', height: '50%',
        background: `radial-gradient(circle, ${T.accent}22, transparent 70%)`,
        filter: 'blur(70px)',
        animation: 'orbC 22s ease-in-out infinite',
        opacity: 0.5 * intensity,
      }} />
      {/* Noise overlay for texture */}
      <div style={{
        position: 'absolute', inset: 0,
        opacity: 0.04, mixBlendMode: 'overlay',
        backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence baseFrequency='0.9' numOctaves='2'/></filter><rect width='200' height='200' filter='url(%23n)'/></svg>")`,
      }} />
    </div>
  );
};

// Particle field — floating specks that drift
const ParticleField = ({ count = 30, color }) => {
  const T = useTheme();
  const c = color || T.accent;
  const particles = React.useMemo(() => Array.from({ length: count }, (_, i) => ({
    left: Math.random() * 100,
    top: Math.random() * 100,
    size: 1 + Math.random() * 2,
    delay: Math.random() * 20,
    duration: 20 + Math.random() * 15,
    opacity: 0.2 + Math.random() * 0.4,
  })), [count]);
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
      {particles.map((p, i) => (
        <div key={i} style={{
          position: 'absolute',
          left: `${p.left}%`,
          top: `${p.top}%`,
          width: p.size, height: p.size,
          borderRadius: '50%',
          background: c,
          opacity: p.opacity,
          boxShadow: `0 0 ${p.size * 4}px ${c}`,
          animation: `floatParticle ${p.duration}s ease-in-out ${p.delay}s infinite`,
        }} />
      ))}
    </div>
  );
};

// Status spacer to clear iOS status bar
const StatusSpacer = ({ h = 54 }) => <div style={{ height: h }} />;

Object.assign(window, {
  useSpring, TickerNumber, StaggerList, StaggerItem,
  SpringButton, TiltCard, PageTransition, AmbientBackground, ParticleField, StatusSpacer,
});
