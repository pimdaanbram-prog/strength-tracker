/* ============================================================
   3D MUSCLE FIGURE — Three.js powered interactive anatomical viewer
   - Real 3D, dragable rotation, auto-spin when idle
   - Each muscle = group of stylized capsules/spheres with emissive material
   - Click a muscle → highlights + glow pulse + triggers onSelect
   - Info panel slides up from bottom of viewport (parent handles this)
   ============================================================ */

// Muscle groups map — each entry = array of {type, pos, size, rotation}
// All positions/sizes tuned for a ~2.6 unit tall humanoid, centered on origin.
const MUSCLE_DEFS = {
  chest: {
    label: 'Borst', dutch: 'Borst', color: '#FF5A1F',
    stats: { volume: '14,200 kg', pr: '92.5 kg', freq: '2×/week', sessions: 48 },
    exercises: ['Bench Press', 'Dumbbell Fly', 'Incline Press', 'Cable Crossover'],
    shapes: [
      { type: 'box', pos: [-0.22, 0.72, 0.36], size: [0.36, 0.34, 0.22], rot: [0, 0, 0.08] },
      { type: 'box', pos: [ 0.22, 0.72, 0.36], size: [0.36, 0.34, 0.22], rot: [0, 0, -0.08] },
    ],
  },
  abs: {
    label: 'Core', dutch: 'Core', color: '#FFB020',
    stats: { volume: '3,800 kg', pr: '45 kg', freq: '3×/week', sessions: 72 },
    exercises: ['Hanging Leg Raise', 'Ab Wheel', 'Plank', 'Cable Crunch'],
    shapes: [
      { type: 'box', pos: [-0.12, 0.36, 0.34], size: [0.18, 0.16, 0.14], rot: [0,0,0] },
      { type: 'box', pos: [ 0.12, 0.36, 0.34], size: [0.18, 0.16, 0.14], rot: [0,0,0] },
      { type: 'box', pos: [-0.12, 0.18, 0.34], size: [0.18, 0.16, 0.14], rot: [0,0,0] },
      { type: 'box', pos: [ 0.12, 0.18, 0.34], size: [0.18, 0.16, 0.14], rot: [0,0,0] },
      { type: 'box', pos: [-0.12, 0.00, 0.34], size: [0.18, 0.16, 0.14], rot: [0,0,0] },
      { type: 'box', pos: [ 0.12, 0.00, 0.34], size: [0.18, 0.16, 0.14], rot: [0,0,0] },
    ],
  },
  shoulders: {
    label: 'Schouders', dutch: 'Schouders', color: '#3D7CFF',
    stats: { volume: '6,200 kg', pr: '52.5 kg', freq: '2×/week', sessions: 52 },
    exercises: ['OHP', 'Lateral Raise', 'Arnold Press', 'Face Pull'],
    shapes: [
      { type: 'sphere', pos: [-0.52, 0.96, 0.08], size: [0.26, 0, 0], rot: [0,0,0] },
      { type: 'sphere', pos: [ 0.52, 0.96, 0.08], size: [0.26, 0, 0], rot: [0,0,0] },
    ],
  },
  biceps: {
    label: 'Biceps', dutch: 'Biceps', color: '#B76DFF',
    stats: { volume: '2,100 kg', pr: '16 kg', freq: '2×/week', sessions: 64 },
    exercises: ['Barbell Curl', 'Hammer Curl', 'Incline Curl', 'Preacher Curl'],
    shapes: [
      { type: 'capsule', pos: [-0.58, 0.55, 0.14], size: [0.12, 0.36, 0], rot: [0,0,0.05] },
      { type: 'capsule', pos: [ 0.58, 0.55, 0.14], size: [0.12, 0.36, 0], rot: [0,0,-0.05] },
    ],
  },
  triceps: {
    label: 'Triceps', dutch: 'Triceps', color: '#3EE8A8',
    stats: { volume: '3,400 kg', pr: '32 kg', freq: '2×/week', sessions: 54 },
    exercises: ['Tricep Pushdown', 'Skull Crusher', 'Close-Grip Bench', 'Overhead Ext.'],
    shapes: [
      { type: 'capsule', pos: [-0.58, 0.55, -0.12], size: [0.13, 0.4, 0], rot: [0,0,0.05] },
      { type: 'capsule', pos: [ 0.58, 0.55, -0.12], size: [0.13, 0.4, 0], rot: [0,0,-0.05] },
    ],
  },
  forearms: {
    label: 'Onderarmen', dutch: 'Onderarmen', color: '#00D9FF',
    stats: { volume: '1,200 kg', pr: '24 kg', freq: '1×/week', sessions: 28 },
    exercises: ['Wrist Curl', 'Reverse Curl', 'Farmer Walk', 'Dead Hang'],
    shapes: [
      { type: 'capsule', pos: [-0.62, 0.06, 0.08], size: [0.10, 0.38, 0], rot: [0,0,0.05] },
      { type: 'capsule', pos: [ 0.62, 0.06, 0.08], size: [0.10, 0.38, 0], rot: [0,0,-0.05] },
    ],
  },
  traps: {
    label: 'Traps', dutch: 'Traps', color: '#FF6FD8',
    stats: { volume: '4,400 kg', pr: '80 kg', freq: '1×/week', sessions: 38 },
    exercises: ['Shrug', 'Upright Row', 'Farmer Walk', 'Rack Pull'],
    shapes: [
      { type: 'box', pos: [-0.2, 1.08, -0.02], size: [0.22, 0.16, 0.26], rot: [0,0,-0.2] },
      { type: 'box', pos: [ 0.2, 1.08, -0.02], size: [0.22, 0.16, 0.26], rot: [0,0,0.2] },
    ],
  },
  lats: {
    label: 'Lats', dutch: 'Lats', color: '#7C8CFF',
    stats: { volume: '9,600 kg', pr: '85 kg', freq: '2×/week', sessions: 44 },
    exercises: ['Pull-up', 'Lat Pulldown', 'Cable Row', 'Pullover'],
    shapes: [
      { type: 'box', pos: [-0.30, 0.55, -0.28], size: [0.28, 0.50, 0.22], rot: [0,0,-0.12] },
      { type: 'box', pos: [ 0.30, 0.55, -0.28], size: [0.28, 0.50, 0.22], rot: [0,0,0.12] },
    ],
  },
  lowerback: {
    label: 'Onderrug', dutch: 'Onderrug', color: '#FFA057',
    stats: { volume: '12,800 kg', pr: '140 kg', freq: '1×/week', sessions: 32 },
    exercises: ['Deadlift', 'Good Morning', 'Back Extension', 'Romanian DL'],
    shapes: [
      { type: 'box', pos: [-0.12, 0.18, -0.32], size: [0.18, 0.32, 0.14], rot: [0,0,0] },
      { type: 'box', pos: [ 0.12, 0.18, -0.32], size: [0.18, 0.32, 0.14], rot: [0,0,0] },
    ],
  },
  quads: {
    label: 'Quads', dutch: 'Quads', color: '#FF3D6E',
    stats: { volume: '18,400 kg', pr: '115 kg', freq: '2×/week', sessions: 56 },
    exercises: ['Squat', 'Leg Press', 'Leg Extension', 'Hack Squat'],
    shapes: [
      { type: 'capsule', pos: [-0.22, -0.45, 0.08], size: [0.20, 0.58, 0], rot: [0,0,0] },
      { type: 'capsule', pos: [ 0.22, -0.45, 0.08], size: [0.20, 0.58, 0], rot: [0,0,0] },
    ],
  },
  hamstrings: {
    label: 'Hamstrings', dutch: 'Hamstrings', color: '#9CFF4A',
    stats: { volume: '8,200 kg', pr: '75 kg', freq: '2×/week', sessions: 42 },
    exercises: ['Romanian DL', 'Leg Curl', 'Good Morning', 'Glute-Ham Raise'],
    shapes: [
      { type: 'capsule', pos: [-0.22, -0.45, -0.14], size: [0.17, 0.58, 0], rot: [0,0,0] },
      { type: 'capsule', pos: [ 0.22, -0.45, -0.14], size: [0.17, 0.58, 0], rot: [0,0,0] },
    ],
  },
  glutes: {
    label: 'Glutes', dutch: 'Glutes', color: '#FFB020',
    stats: { volume: '11,400 kg', pr: '120 kg', freq: '2×/week', sessions: 48 },
    exercises: ['Hip Thrust', 'Bulgarian Split', 'RDL', 'Cable Kickback'],
    shapes: [
      { type: 'sphere', pos: [-0.22, -0.12, -0.24], size: [0.26, 0, 0], rot: [0,0,0] },
      { type: 'sphere', pos: [ 0.22, -0.12, -0.24], size: [0.26, 0, 0], rot: [0,0,0] },
    ],
  },
  calves: {
    label: 'Kuiten', dutch: 'Kuiten', color: '#A0E9FF',
    stats: { volume: '3,200 kg', pr: '60 kg', freq: '2×/week', sessions: 36 },
    exercises: ['Standing Raise', 'Seated Raise', 'Donkey Raise', 'Jump Rope'],
    shapes: [
      { type: 'capsule', pos: [-0.22, -1.12, -0.04], size: [0.14, 0.36, 0], rot: [0,0,0] },
      { type: 'capsule', pos: [ 0.22, -1.12, -0.04], size: [0.14, 0.36, 0], rot: [0,0,0] },
    ],
  },
};

// Base humanoid "skin" — simple but anatomical: head, neck, torso, pelvis, arms, legs
const SKIN = [
  { type: 'sphere',  pos: [0, 1.42, 0],    size: [0.26] },              // head
  { type: 'capsule', pos: [0, 1.18, 0],    size: [0.10, 0.10] },        // neck
  { type: 'box',     pos: [0, 0.70, 0],    size: [0.88, 0.80, 0.42] },  // torso
  { type: 'box',     pos: [0, 0.18, 0],    size: [0.64, 0.30, 0.38] },  // pelvis band
  { type: 'sphere',  pos: [-0.22, -0.08, 0], size: [0.24] },            // hip L
  { type: 'sphere',  pos: [ 0.22, -0.08, 0], size: [0.24] },            // hip R
  // arms — upper + lower stylized
  { type: 'capsule', pos: [-0.58, 0.55, 0], size: [0.13, 0.48] },
  { type: 'capsule', pos: [ 0.58, 0.55, 0], size: [0.13, 0.48] },
  { type: 'capsule', pos: [-0.62, 0.06, 0], size: [0.11, 0.40] },
  { type: 'capsule', pos: [ 0.62, 0.06, 0], size: [0.11, 0.40] },
  { type: 'sphere',  pos: [-0.64, -0.18, 0], size: [0.09] },            // hand L
  { type: 'sphere',  pos: [ 0.64, -0.18, 0], size: [0.09] },            // hand R
  // legs — upper + lower
  { type: 'capsule', pos: [-0.22, -0.48, 0], size: [0.20, 0.60] },
  { type: 'capsule', pos: [ 0.22, -0.48, 0], size: [0.20, 0.60] },
  { type: 'capsule', pos: [-0.22, -1.14, 0], size: [0.15, 0.42] },
  { type: 'capsule', pos: [ 0.22, -1.14, 0], size: [0.15, 0.42] },
  { type: 'sphere',  pos: [-0.22, -1.42, 0.08], size: [0.13] },         // foot L
  { type: 'sphere',  pos: [ 0.22, -1.42, 0.08], size: [0.13] },         // foot R
];

/* ========== COMPONENT ========== */

const MuscleFigure = ({
  selectedMuscle = null,
  onSelect = () => {},
  height = 460,
  autoRotate = true,
  showLabels = false,
}) => {
  const T = useTheme();
  const mountRef = React.useRef(null);
  const stateRef = React.useRef({
    THREE: null, scene: null, camera: null, renderer: null,
    muscleMeshes: {}, skinMeshes: [], raycaster: null, pointer: null,
    rotY: 0, targetRotY: 0, dragging: false, lastX: 0, lastY: 0,
    rotX: -0.02, targetRotX: -0.02,
    cameraDist: 4.0, targetCameraDist: 4.0,
    idleTimer: 0, isUserIdle: true,
    hovered: null, raf: null,
    selected: selectedMuscle,
    accent: T.accent,
  });
  const [loaded, setLoaded] = React.useState(false);

  // Keep latest selected / accent in ref without re-running setup
  React.useEffect(() => { stateRef.current.selected = selectedMuscle; }, [selectedMuscle]);
  React.useEffect(() => { stateRef.current.accent = T.accent; }, [T.accent]);

  React.useEffect(() => {
    let cancelled = false;
    const s = stateRef.current;
    const mount = mountRef.current;
    if (!mount) return;

    // Load Three.js once
    const loadThree = () => new Promise((resolve) => {
      if (window.THREE) return resolve(window.THREE);
      const tag = document.createElement('script');
      tag.src = 'https://unpkg.com/three@0.160.0/build/three.min.js';
      tag.onload = () => resolve(window.THREE);
      document.head.appendChild(tag);
    });

    loadThree().then((THREE) => {
      if (cancelled || !mount) return;
      s.THREE = THREE;

      const w = mount.clientWidth;
      const h = mount.clientHeight;
      const scene = new THREE.Scene();
      scene.background = null;

      // fog for depth
      scene.fog = new THREE.Fog(0x060608, 5, 9);

      const camera = new THREE.PerspectiveCamera(32, w / h, 0.1, 50);
      camera.position.set(0, 0.1, s.cameraDist);
      camera.lookAt(0, 0, 0);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(w, h);
      renderer.setClearColor(0x000000, 0);
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.1;
      mount.appendChild(renderer.domElement);

      // Lighting — premium studio setup
      const ambient = new THREE.AmbientLight(0x5566aa, 0.35);
      scene.add(ambient);
      const keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
      keyLight.position.set(2, 3, 4);
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 0.1;
      keyLight.shadow.camera.far = 15;
      keyLight.shadow.camera.left = -2;
      keyLight.shadow.camera.right = 2;
      keyLight.shadow.camera.top = 3;
      keyLight.shadow.camera.bottom = -2;
      keyLight.shadow.bias = -0.0005;
      scene.add(keyLight);

      const rim = new THREE.DirectionalLight(0x88aaff, 0.9);
      rim.position.set(-3, 1, -2);
      scene.add(rim);

      const accentLight = new THREE.PointLight(new THREE.Color(s.accent), 2.0, 6);
      accentLight.position.set(0, 0.5, 2.5);
      scene.add(accentLight);
      s.accentLight = accentLight;

      // Ground glow plane
      const groundGeo = new THREE.CircleGeometry(1.6, 48);
      const groundMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(s.accent),
        transparent: true, opacity: 0.12,
      });
      const ground = new THREE.Mesh(groundGeo, groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.position.y = -1.62;
      scene.add(ground);
      s.ground = ground;

      // Root group (we'll rotate this, not the camera)
      const root = new THREE.Group();
      scene.add(root);
      s.root = root;

      // Helper: build shape
      const buildShape = (shape, mat) => {
        let geom;
        if (shape.type === 'sphere') {
          geom = new THREE.SphereGeometry(shape.size[0], 20, 20);
        } else if (shape.type === 'box') {
          geom = new THREE.BoxGeometry(shape.size[0], shape.size[1], shape.size[2]);
          // soften box edges by scaling normals (fake chamfer via material roughness)
        } else if (shape.type === 'capsule') {
          geom = new THREE.CapsuleGeometry(shape.size[0], shape.size[1], 8, 18);
        }
        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.set(shape.pos[0], shape.pos[1], shape.pos[2]);
        if (shape.rot) mesh.rotation.set(shape.rot[0] || 0, shape.rot[1] || 0, shape.rot[2] || 0);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        return mesh;
      };

      // Skin — base humanoid
      const skinMat = new THREE.MeshStandardMaterial({
        color: 0x1a1d28,
        roughness: 0.6, metalness: 0.25,
        emissive: 0x0b0d14, emissiveIntensity: 0.5,
      });
      SKIN.forEach((shape) => {
        const m = buildShape({ ...shape, size: shape.size.length === 1 ? [shape.size[0], 0, 0] : [shape.size[0], shape.size[1] ?? 0, shape.size[2] ?? 0] }, skinMat);
        root.add(m);
        s.skinMeshes.push(m);
      });

      // Muscle groups — each with its own emissive material
      Object.entries(MUSCLE_DEFS).forEach(([key, def]) => {
        const col = new THREE.Color(def.color);
        const mat = new THREE.MeshStandardMaterial({
          color: col.clone().multiplyScalar(0.35),
          roughness: 0.45, metalness: 0.4,
          emissive: col.clone().multiplyScalar(0.15),
          emissiveIntensity: 0.6,
        });
        const group = new THREE.Group();
        group.userData.muscleKey = key;
        group.userData.baseColor = col.clone();
        group.userData.material = mat;
        def.shapes.forEach((shape) => {
          const m = buildShape(shape, mat);
          m.userData.muscleKey = key;
          group.add(m);
        });
        root.add(group);
        s.muscleMeshes[key] = group;
      });

      s.scene = scene; s.camera = camera; s.renderer = renderer;
      s.raycaster = new THREE.Raycaster();
      s.pointer = new THREE.Vector2();

      // === Interactions ===
      const getPointer = (e) => {
        const rect = renderer.domElement.getBoundingClientRect();
        const cx = e.clientX ?? (e.touches && e.touches[0]?.clientX) ?? 0;
        const cy = e.clientY ?? (e.touches && e.touches[0]?.clientY) ?? 0;
        s.pointer.x = ((cx - rect.left) / rect.width) * 2 - 1;
        s.pointer.y = -((cy - rect.top) / rect.height) * 2 + 1;
        return { cx, cy };
      };

      const onDown = (e) => {
        const { cx, cy } = getPointer(e);
        s.dragging = true;
        s.dragMoved = false;
        s.lastX = cx; s.lastY = cy;
        s.isUserIdle = false;
        s.idleTimer = 0;
      };
      const onMove = (e) => {
        const { cx, cy } = getPointer(e);
        if (s.dragging) {
          const dx = cx - s.lastX;
          const dy = cy - s.lastY;
          if (Math.abs(dx) + Math.abs(dy) > 3) s.dragMoved = true;
          s.targetRotY += dx * 0.01;
          s.targetRotX = Math.max(-0.7, Math.min(0.7, s.targetRotX + dy * 0.005));
          s.lastX = cx; s.lastY = cy;
        } else {
          // hover highlight
          s.raycaster.setFromCamera(s.pointer, camera);
          const meshes = Object.values(s.muscleMeshes).flatMap(g => g.children);
          const hits = s.raycaster.intersectObjects(meshes, false);
          s.hovered = hits[0]?.object?.userData?.muscleKey || null;
          renderer.domElement.style.cursor = s.hovered ? 'pointer' : 'grab';
        }
      };
      const onUp = (e) => {
        if (s.dragging && !s.dragMoved) {
          // treat as click
          s.raycaster.setFromCamera(s.pointer, camera);
          const meshes = Object.values(s.muscleMeshes).flatMap(g => g.children);
          const hits = s.raycaster.intersectObjects(meshes, false);
          const key = hits[0]?.object?.userData?.muscleKey;
          if (key) onSelect(key);
          else onSelect(null);
        }
        s.dragging = false;
      };

      const el = renderer.domElement;
      el.style.touchAction = 'none';
      el.style.cursor = 'grab';
      el.addEventListener('pointerdown', onDown);
      el.addEventListener('pointermove', onMove);
      el.addEventListener('pointerup', onUp);
      el.addEventListener('pointerleave', () => { s.dragging = false; s.hovered = null; });

      // resize
      const ro = new ResizeObserver(() => {
        const w = mount.clientWidth, h = mount.clientHeight;
        if (w > 0 && h > 0) {
          renderer.setSize(w, h);
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
        }
      });
      ro.observe(mount);
      s.ro = ro;

      // === Render loop ===
      const clock = new THREE.Clock();
      const animate = () => {
        const dt = clock.getDelta();
        const t = clock.getElapsedTime();

        // Idle check — auto rotate after 2.5s
        s.idleTimer += dt;
        if (!s.dragging && autoRotate && s.idleTimer > 2.5) {
          s.targetRotY += dt * 0.15;
        }

        // Smoothly ease rotations
        s.rotY += (s.targetRotY - s.rotY) * Math.min(1, dt * 6);
        s.rotX += (s.targetRotX - s.rotX) * Math.min(1, dt * 6);
        root.rotation.y = s.rotY;
        root.rotation.x = s.rotX;

        // Camera ease
        s.cameraDist += (s.targetCameraDist - s.cameraDist) * Math.min(1, dt * 3);
        camera.position.z = s.cameraDist;

        // subtle breathe
        root.position.y = Math.sin(t * 1.4) * 0.012;

        // Update muscle emission — selected pulses, hovered brightens, others dim
        const selected = s.selected;
        const hovered = s.hovered;
        Object.entries(s.muscleMeshes).forEach(([key, group]) => {
          const mat = group.userData.material;
          const base = group.userData.baseColor;
          const isSel = selected === key;
          const isHov = hovered === key;
          const any = selected || hovered;

          let targetEmit = 0.5;
          let targetColScale = 0.35;
          let targetOpacity = 1.0;

          if (isSel) {
            // strong pulse
            targetEmit = 1.6 + Math.sin(t * 4) * 0.4;
            targetColScale = 0.9;
          } else if (isHov) {
            targetEmit = 1.1;
            targetColScale = 0.7;
          } else if (any) {
            targetEmit = 0.15;
            targetColScale = 0.2;
          }

          // ease material params
          mat.emissiveIntensity += (targetEmit - mat.emissiveIntensity) * Math.min(1, dt * 8);
          const c = mat.color;
          const target = base.clone().multiplyScalar(targetColScale);
          c.lerp(target, Math.min(1, dt * 8));
          const em = mat.emissive;
          const emTarget = base.clone().multiplyScalar(Math.min(1, targetEmit * 0.5));
          em.lerp(emTarget, Math.min(1, dt * 8));
        });

        // accent light pulses softly
        s.accentLight.color.lerp(new THREE.Color(s.accent), Math.min(1, dt * 4));
        s.accentLight.intensity = 1.6 + Math.sin(t * 1.5) * 0.3;

        // ground color follows accent
        s.ground.material.color.lerp(new THREE.Color(s.accent), Math.min(1, dt * 4));

        // camera auto-zoom when a muscle is selected
        s.targetCameraDist = selected ? 3.3 : 4.0;

        renderer.render(scene, camera);
        s.raf = requestAnimationFrame(animate);
      };
      s.raf = requestAnimationFrame(animate);
      setLoaded(true);
    });

    return () => {
      cancelled = true;
      const s = stateRef.current;
      if (s.raf) cancelAnimationFrame(s.raf);
      if (s.ro) s.ro.disconnect();
      if (s.renderer) {
        s.renderer.dispose();
        if (s.renderer.domElement && s.renderer.domElement.parentNode) {
          s.renderer.domElement.parentNode.removeChild(s.renderer.domElement);
        }
      }
      // dispose geometries/materials
      if (s.scene) {
        s.scene.traverse((obj) => {
          if (obj.geometry) obj.geometry.dispose();
          if (obj.material) {
            if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
            else obj.material.dispose();
          }
        });
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div style={{ position: 'relative', width: '100%', height }}>
      <div ref={mountRef} style={{ position: 'absolute', inset: 0 }} />
      {!loaded && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: T.textMute, fontFamily: T.mono, fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase',
        }}>
          Loading anatomy…
        </div>
      )}
      {/* subtle grid overlay */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        backgroundImage: 'radial-gradient(circle at center, transparent 60%, rgba(0,0,0,0.5) 100%)',
      }} />
    </div>
  );
};

Object.assign(window, { MuscleFigure, MUSCLE_DEFS });
