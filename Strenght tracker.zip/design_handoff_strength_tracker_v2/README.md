# Handoff: Strength Tracker v2 — Glassmorphic Rework

## Overview
A bold visual rework of a Dutch-language strength-training iOS app. The v2 direction moves the app from a standard flat dashboard to a **glassmorphic "iOS 26" aesthetic**, with a rotatable 3D anatomical figure as the emotional centerpiece of the Progress screen, and a live in-app accent-color switcher so the user can re-theme the whole product in one tap.

The app is in Dutch (e.g. "Start nieuwe training", "Volgende oefening", "Instellingen").

## About the Design Files
The files in this bundle are **design references created in HTML** — high-fidelity prototypes showing intended look and behavior, not production code to copy directly. All design logic lives in a single HTML file that boots React via Babel-in-browser; this is a presentation format, not a shipping format.

Your task is to **recreate these HTML designs in the target codebase's existing environment** (likely SwiftUI for iOS, or React Native) using its established patterns, navigation, and state libraries. If no target codebase exists yet, choose the framework most appropriate for the product (native iOS / SwiftUI is the natural fit given the design language) and implement there.

The JSX files under `design-reference/source/` are useful for lifting exact token values, icon lists, layout math, and animation timings — not for copy-pasting whole components.

## Fidelity
**High-fidelity (hifi).** All colors, typography, spacing, border radii, shadow values, and animation timings are final and should be reproduced exactly. The only flexibility is the execution layer (how you build a glass card in SwiftUI differs from a browser prototype) — the *visual result* should match.

---

## Design Tokens

### Colors — base palette (dark theme is the only theme)
| Token | Value | Usage |
|---|---|---|
| `bg` | `#060608` | App background |
| `bgElev` | `#0D0D12` | Elevated surface base (behind glass) |
| `surface` | `rgba(22, 22, 28, 0.55)` | Glass card fill |
| `surfaceHi` | `rgba(30, 30, 38, 0.7)` | Elevated glass card fill |
| `glassBorder` | `rgba(255, 255, 255, 0.08)` | Glass card border |
| `glassHighlight` | `rgba(255, 255, 255, 0.12)` | Inner top edge highlight on glass |
| `text` | `#F5F5F7` | Primary text |
| `textDim` | `#A1A1AA` | Secondary text |
| `textMute` | `#52525B` | Tertiary / metadata |
| `success` | `#3EE8A8` | PRs, streaks, positive deltas |
| `warning` | `#FFB020` | Flame / streak accents |
| `danger` | `#FF5470` | Error / destructive |

### Accent colors (user-switchable in Settings)
Each accent has two stops used in a 135° linear gradient.

| Key | Name | c1 | c2 | Glow (used for shadows) |
|---|---|---|---|---|
| `electric` | Electric | `#00D4FF` | `#0095FF` | `rgba(0,212,255,0.45)` |
| `sunset` | Sunset | `#FF6B35` | `#F7931E` | `rgba(255,107,53,0.45)` |
| `violet` | Violet | `#A855F7` | `#7C3AED` | `rgba(168,85,247,0.45)` |
| `mint` | Mint | `#3EE8A8` | `#10B981` | `rgba(62,232,168,0.45)` |
| `coral` | Coral | `#FF5470` | `#E11D48` | `rgba(255,84,112,0.45)` |
| `gold` | Gold | `#FFB020` | `#F59E0B` | `rgba(255,176,32,0.45)` |

**Default accent:** `electric`.
**Accent usage:** primary CTAs, selected states, progress bars, 3D muscle highlights, bottom-nav active icon + pill, glows on live surfaces. Persist choice per-user.

### Typography
- **Display** (screen titles, large numbers): `Space Grotesk`, weights 500/600/700, `letter-spacing: -0.03em` on large sizes, `line-height: 1.05`.
- **Body / UI** (everything else): `Inter`, weights 400/500/600/700.
- **Mono** (labels, metadata, numeric-tabular, section eyebrows): `JetBrains Mono`, 400/500/600/700, usually uppercased with `letter-spacing: 0.10–0.14em`.

### Type scale (actual values used)
| Role | Size | Weight | Family |
|---|---|---|---|
| Screen title | 28–32px | 700 | Display |
| Big-number / ticker | 22–34px | 700 | Display |
| Section label (eyebrow) | 9–10px | 700 uppercase | Mono |
| Card title | 14px | 600 | Body |
| Card body | 12.5–13.5px | 500 | Body |
| Meta / unit / date | 10–11px | 500–600 | Mono |
| Pill | 10–11px | 600–700 | Mono |

### Spacing
Base 4-pt grid. Common values: `4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 40, 54`.
- Screen horizontal padding: `14px` for card rows, `16–20px` for text.
- Top status-bar spacer: `54px` (sits below the iOS notch).

### Border radius
| Token | Value | Usage |
|---|---|---|
| `sm` | 6–8px | Inline chips, heatmap cells |
| `md` | 10–12px | Small icon tiles, input pills |
| `lg` | 14–16px | Buttons, search bars, icon buttons |
| `xl` | 18–22px | Primary cards |
| `pill` | 999px | Category filters, pills, CTAs |

### Shadows & effects
- **Glass card**: `background: rgba(22,22,28,0.55); backdrop-filter: blur(20px) saturate(180%); border: 1px solid rgba(255,255,255,0.08); box-shadow: 0 8px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.06);`
- **Elevated glass** (hero cards): boost blur to `24px`, add inner highlight `inset 0 1px 0 rgba(255,255,255,0.12)`.
- **Accent glow** (on primary CTAs, active nav pill, PR badges): `box-shadow: 0 8px 24px <accent.glow>, 0 0 0 1px <accent.c1>40;`
- **Text glow** on big numbers during PR celebration: `text-shadow: 0 0 24px <accent.glow>;`

---

## Screens / Views

### 01 · Dashboard (Home)
**Purpose:** Landing screen. See today's planned workout, streak, weekly volume, recent PRs. Start a session.

**Layout:**
- Vertical scroll, full-bleed.
- Top: status-bar spacer (54px), then a greeting block (eyebrow "GOEDEMORGEN" + display name "Pim").
- **Hero CTA card** (elevated glass, 18px padding, 22px radius): full-width, 135° accent gradient overlay at low opacity. Big title "Push Day", subtitle "5 oefeningen · ~45 min", and a gradient-filled "Start" button (44px tall, pill radius, accent glow).
- **Stat grid** — 2 columns, 10px gap: today's volume (kg), streak (days with flame icon in warning color).
- **Streak band**: glass card with a horizontal 7-day dot row; active days use accent gradient, today has accent glow ring.
- **Recent PRs list**: 2–3 rows. Each row: left 4px accent-colored bar, exercise name + date (mono dim), right side weight + "PR" pill (success tone).
- **Bottom nav** (fixed): 4 tabs — Home / Workout / Progress / Settings. Active tab shows a pill-shaped accent-gradient background behind the icon with accent glow; inactive tabs are `textDim` icons only.

**Copy (Dutch):**
- Eyebrow: "GOEDEMORGEN"
- Hero card title: "Push Day" · subtitle "5 oefeningen · ~45 min"
- Stat labels: "VOLUME VANDAAG", "STREAK"
- Section label: "RECENTE PR'S"

### 02 · Active Workout
**Purpose:** The live session screen. Log sets, move between exercises, rest timer.

**Layout:**
- Top bar: back chevron (left), session timer pill (center, mono, live-counting), finish-button (right, accent-filled pill).
- **Current exercise card** (elevated glass): exercise name as display-28, subtitle with target muscle group.
- **Sets table**: rows with set index, weight input (tabular mono), reps input, and a big circular check button. Completed sets get a muted green tick and a subtle strikethrough on the numbers; the active row has an accent-ring glow.
- **Between-set rest timer** (when active): full-width accent-gradient progress bar counting down, with mono time remaining.
- "Volgende oefening" button (outline glass) at bottom above nav.

**Copy:** "Oefening 2 van 5", "Volgende oefening", "Set", "Kg", "Reps", "Klaar".

### 03 · Exercise Detail
**Purpose:** Deep-dive on one exercise — PR, history sparkline, per-session list.

**Layout:**
- No top nav bar — immersive. Hero block with a large radial accent glow bleeding from the top-right corner.
- Back chevron top-left, bookmark icon top-right (both 40×40 glass icon buttons, 14px radius).
- Eyebrow pill "Borst · Compound" (accent-tinted glass pill), display-32 title "Barbell Bench Press", mono subtitle listing target muscles.
- **3-up stat strip**: PR / Last / Lifetime sets. Each tile is a small glass card, centered text, mono eyebrow label, display-24 number (ticker-animated on mount), unit label under.
- **Progression chart**: glass card with an 8-point SVG area chart (accent gradient fill below, accent stroke line, accent-glow filter, last point is a larger filled dot).
- **Historie** list: session rows, each a glass card with a left accent-color bar (success color + glow when a PR was set that session), date, mono set breakdown "80×10 · 82.5×8 · 85×6", and a right-aligned top-weight number.

### 04 · Exercises Library
**Purpose:** Browse all exercises, filter by muscle group, search.

**Layout:**
- **Sticky header** (blurred glass bar, not a solid fill): eyebrow "LIBRARY", display-28 "Oefeningen", filter icon button (right). Search input below — glass card 14px radius, inset search icon, right-side mono count badge (e.g. "56").
- **Category chips** row (horizontal scroll, hide-scrollbar): "Alle", "Borst", "Rug", "Benen", "Schouder", "Armen", "Core". Active chip is accent-gradient-filled with accent glow; inactive is glass-outline.
- **Exercise list**: rows with a 50×50 accent-tinted icon tile (dumbbell glyph in accent color), name, mono meta "BORST · INTER · 127× DONE", right-aligned PR in success color + "PR · KG" mono label.

### 05 · History
**Purpose:** See activity density and recent sessions.

**Layout:**
- Eyebrow "HISTORIE", display-30 title "April 2026".
- **Activity heatmap card** (elevated glass): top row — eyebrow "ACTIVITEIT", big number (trainings this month), right side flame pill with mono streak count. 7-column weekday header (M D W D V Z Z), then 5 rows of day cells. Cells animate in staggered (15ms × index). Intensity scale is 4 levels: empty / accent-26%/accent-53%/accent-full, with a glow on max-intensity cells. Legend at bottom-right ("Minder" … "Meer").
- **Recente trainingen** list: session cards with a date tile on the left (small glass chip, mono "APR", display-22 day number, mono weekday), session name + PR pill when applicable, duration + exercise count in mono, and a green PR summary line when applicable.

### 06 · Progress (the hero screen)
**Purpose:** Emotional, visual status. Show muscle-group coverage this week on a rotatable 3D figure.

**Layout:**
- Eyebrow "PROGRESSIE", display-30 title "Deze week".
- **3D figure hero** (fills ~55% of viewport height): a stylized low-poly humanoid silhouette built from primitive meshes (head, torso, arms, legs). Each major muscle group is a separately shaded mesh that can:
  - **Idle**: base color `#1F1F26` with subtle emissive.
  - **Active/selected**: emissive color set to the user's accent, emissive intensity `~1.2`, additive outline pulse.
  - **Worked this week**: tinted toward accent with reduced emissive intensity.
- User can **drag-rotate** the figure (Y-axis) and **tap** muscle groups to select them. The scene is lit with a soft key + rim light and a subtle ground shadow.
- Below the 3D canvas: a **muscle-group chip row** scrollable horizontally — Borst, Rug, Benen, Schouder, Armen, Core — selection here mirrors the 3D selection and highlights the same mesh.
- **Selected muscle detail card**: glass card showing sets/week, volume delta, last exercise, and a miniature sparkline.

**Implementation note for native:** In SwiftUI use `RealityKit` / `SceneKit`; in React Native use `expo-gl + three`. Rigged/animated mesh not required — static posed mesh with per-group materials is enough.

### 07 · Settings
**Purpose:** User profile, accent-color picker, preferences.

**Layout:**
- Eyebrow "INSTELLINGEN", display-30 "Jouw vibe".
- **Profile card** (elevated glass): 56×56 accent-gradient tile with display initial "P", name "Pim", mono sub "Member sinds jan 2024 · 248 sessions", right chevron.
- **Accent color picker** section:
  - Section label left: palette icon + "Accent kleur". Section label right: mono uppercased current accent name in accent color.
  - 3-column grid of 6 accent cards (glass, 16px radius). Each card shows a 40×40 rounded square filled with the accent's 135° gradient, bottom caption with the accent name.
  - **Selected state**: 1.5px border in `c1`, soft glow `0 8px 24px c1·55`, and a 16×16 check-badge top-right with the accent gradient and a black check.
  - Changing accent updates the *entire app* immediately — primary buttons, selected nav pill, PR pills, muscle highlights on the 3D figure, progress rings, etc. Persist to user storage.
  - Preview strip below the grid: a bar (accent gradient) and a small soft-accent tile with a sparkles icon.
- **Voorkeuren** list: grouped glass card with 4 rows — Eenheden (Kilogram), Notificaties (Aan), Animaties (Max), Account (Pim). Each row: 34×34 icon tile, label, right-aligned mono value, right chevron. Rows separated by 1px `glassBorder` divider.

---

## Interactions & Behavior

### Navigation
- Bottom nav is always visible on Home, Workout, Progress, Settings. Exercise Detail and Library are pushed screens (no nav, or nav hidden).
- Tab switches are instant; pushed screens slide in from the right (`transform: translateX(100% → 0)` over 280ms, `cubic-bezier(0.2, 0.8, 0.2, 1)`).

### Page transitions
- Forward: new screen slides in from right + fades in (280ms `cubic-bezier(0.2,0.8,0.2,1)`).
- Back: outgoing screen slides right; incoming comes from left.

### Card entry (stagger)
- Lists and grids stagger children by 50–70ms. Each child animates `translateY(16px) opacity(0)` → `0 / 1` over 400ms with `cubic-bezier(0.2, 0.8, 0.2, 1)`.

### Button / tap
- Tap scales the target to `0.94–0.96` for the press duration (spring-back), using a 150ms `cubic-bezier(0.34, 1.56, 0.64, 1)` release.
- Primary CTAs add a subtle inner highlight flash on tap.

### Number ticker
- Numeric stats on screen mount animate from 0 → final value over 700ms using `easeOutCubic`. Keep locale formatting (NL uses `,` as decimal).

### 3D figure interaction
- Drag horizontally = rotate around Y. Momentum decay (friction 0.92/frame). Clamp X-rotation to small range for subtle tilt.
- Tap a mesh = select it; emissive intensity pulses `1.2 → 1.6 → 1.2` over 600ms.
- On tab mount: figure does a single auto-rotation of ~30° over 1.2s to telegraph interactivity.

### Background orbs (ambient)
- Each screen has 2–3 fixed-position radial-gradient orbs behind the content (blur 40px, accent-tinted) that slowly animate via `orbA`/`orbB`/`orbC` keyframes (7–12s durations, translate + scale loops). They're decorative — never block touches (`pointer-events: none`).

### Rest timer
- Linear fill bar, counts down real-time. On finish, plays a haptic + a subtle green pulse across the card border.

### Accent change
- Switching accent re-tints everything live with a 200ms CSS variable crossfade. The 3D figure updates its emissive material on the next frame.

---

## State Management
Minimum state to carry:
- `accent: 'electric' | 'sunset' | 'violet' | 'mint' | 'coral' | 'gold'` — persisted.
- `currentScreen` — for the prototype; in native this becomes the nav stack.
- `activeSession`: `{ exerciseIndex, sets: [{kg, reps, done}], restTimer }`.
- `selectedMuscle` on the Progress screen — drives both the 3D highlight and the detail card.
- `workoutHistory` — array of sessions, used by Dashboard (streak, recent PRs), Exercise Detail (sparkline + list), and History (heatmap).
- `exerciseLibrary` — static for now.

---

## Assets
No external raster assets. Everything is SVG icons (drawn in-code), CSS gradients, or Three.js primitive meshes. The icon set used (see `source/*.jsx`):
- Navigation: `home`, `dumbbell`, `chart`, `settings`, `chevron-left`, `chevron-right`
- Actions: `plus`, `check`, `bookmark`, `filter`, `search`
- Status: `flame`, `sparkles`, `clock`, `weight`, `bell`, `palette`, `user`

Recreate these using the target platform's icon library (SF Symbols on iOS, lucide on web/RN) — match the visual weight (1.5–2px stroke, rounded caps/joins).

---

## Files in this bundle

```
design_handoff_strength_tracker_v2/
├── README.md                              ← this file
└── design-reference/
    ├── Strength Tracker v2.html           ← open in a browser; all 7 screens interactive
    └── source/
        ├── theme.jsx                      ← accent palette + glass tokens + shared primitives
        ├── animations.jsx                 ← ticker, stagger, page-transition helpers
        ├── muscle-figure.jsx              ← Three.js 3D figure component
        ├── screens-core.jsx               ← Dashboard, Workout, Progress
        └── screens-more.jsx               ← Exercise Detail, Exercises, History, Settings
```

Open `Strength Tracker v2.html` in any modern browser to see the live prototype with all screens, transitions, and the accent picker functional. Drag the canvas, click artboard labels to focus-view a single screen, and use Settings → Accent to see the full re-theme in action.
